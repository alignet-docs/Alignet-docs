<?php
/**
 * Payme Validation Controller
 * Processes payment result from Flex SDK callback
 */

class PaymeValidationModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        // Handle POST from Flex SDK response callback
        if (Tools::isSubmit('payment_result') || Tools::getValue('payment_result')) {
            $this->processPaymentResult();
            return;
        }

        // Handle GET redirect from Payme (redirect_url)
        if (Tools::getValue('merchant_operation_number') || Tools::getValue('status')) {
            $this->processRedirectReturn();
            return;
        }

        // Fallback: redirect to checkout
        Tools::redirect('index.php?controller=order&step=1');
    }

    /**
     * Get human-readable payment method name
     */
    private function getMethodDisplayName($method)
    {
        $names = [
            'CARD' => 'Tarjeta de Crédito/Débito',
            'YAPE' => 'Yape',
            'QR' => 'Código QR',
            'BANK_TRANSFER' => 'Transferencia Bancaria',
            'CUOTEALO' => 'Cuotéalo BCP',
            'PAGOEFECTIVO' => 'PagoEfectivo',
        ];
        $key = strtoupper(trim($method));
        return isset($names[$key]) ? $names[$key] : $method;
    }

    private function processPaymentResult()
    {
        $resultJson = Tools::getValue('payment_result');
        $result = json_decode($resultJson, true);

        if (!$result) {
            $this->jsonError('Invalid payment result');
            return;
        }

        // Validate payment — check for explicit denial first, then success
        $actionCode = null;
        if (isset($result['action_code'])) {
            $actionCode = $result['action_code'];
        } elseif (isset($result['response_code'])) {
            $actionCode = $result['response_code'];
        } elseif (isset($result['transaction']['action_code'])) {
            $actionCode = $result['transaction']['action_code'];
        } elseif (isset($result['transaction']['response_code'])) {
            $actionCode = $result['transaction']['response_code'];
        }

        // Check for explicit denial
        $isDenied = false;
        if (isset($result['transaction']['state'])) {
            $state = strtoupper($result['transaction']['state']);
            if (in_array($state, ['DENEGADO', 'INVALIDO', 'DENIED', 'REJECTED', 'FAILED'])) {
                $isDenied = true;
            }
        }
        if (!$isDenied && $actionCode !== null) {
            $codeStr = str_pad($actionCode, 2, '0', STR_PAD_LEFT);
            if ($codeStr !== '00') {
                $isDenied = true;
            }
        }

        $isSuccess = false;
        if (!$isDenied) {
            $isSuccess = ($actionCode === '00' || $actionCode === 0 || $actionCode === '0')
                || (isset($result['transaction']['state']) && strtoupper($result['transaction']['state']) === 'AUTORIZADO')
                || (isset($result['status']) && in_array($result['status'], ['AUTHORIZED', 'APPROVED']))
                || (isset($result['success']) && ($result['success'] === 'true' || $result['success'] === true));
        }

        if (!$isSuccess) {
            // Payment denied — create order with error status and redirect to confirmation
            $cart = $this->context->cart;
            if ($cart && $cart->id) {
                $customer = new Customer($cart->id_customer);
                if (Validate::isLoadedObject($customer)) {
                    $codeStr = $actionCode !== null ? str_pad($actionCode, 2, '0', STR_PAD_LEFT) : 'N/A';
                    $stateStr = isset($result['transaction']['state']) ? $result['transaction']['state'] : '';
                    $operationNumber = $this->context->cookie->payme_operation_number ?? '';
                    $total = (float) $cart->getOrderTotal(true, Cart::BOTH);
                    $currency = $this->context->currency;

                    try {
                        $selectedMethod = $this->context->cookie->payme_selected_method ?? '';
                        $methodLabel = $selectedMethod ? $this->getMethodDisplayName($selectedMethod) : '';
                        $paymentName = $this->module->displayName . ($methodLabel ? ' — ' . $methodLabel : '');

                        $this->module->validateOrder(
                            (int) $cart->id,
                            (int) Configuration::get('PS_OS_ERROR'),
                            $total,
                            $paymentName,
                            'Pago denegado. Código: ' . $codeStr . ($stateStr ? ' — Estado: ' . $stateStr : '') . ' | Op: ' . $operationNumber,
                            ['transaction_id' => $operationNumber],
                            (int) $currency->id,
                            false,
                            $customer->secure_key
                        );

                        $orderId = $this->module->currentOrder;

                        $this->module->updateTransactionStatus(
                            $operationNumber,
                            'failed',
                            $orderId,
                            $resultJson
                        );

                        $confirmUrl = $this->context->link->getPageLink(
                            'order-confirmation',
                            true,
                            null,
                            [
                                'id_cart' => (int) $cart->id,
                                'id_module' => (int) $this->module->id,
                                'id_order' => $orderId,
                                'key' => $customer->secure_key,
                            ]
                        );

                        header('Content-Type: application/json');
                        echo json_encode([
                            'success' => false,
                            'redirect' => $confirmUrl,
                            'error' => 'Pago denegado. Código: ' . $codeStr,
                        ]);
                        exit;
                    } catch (Exception $e) {
                        $this->module->logMessage('Failed order creation error: ' . $e->getMessage(), 'error');
                    }
                }
            }

            $codeStr = $actionCode !== null ? str_pad($actionCode, 2, '0', STR_PAD_LEFT) : 'N/A';
            $stateStr = isset($result['transaction']['state']) ? $result['transaction']['state'] : '';
            $this->jsonError('Pago rechazado. Código: ' . $codeStr . ($stateStr ? ' — Estado: ' . $stateStr : ''));
            return;
        }

        $cart = $this->context->cart;
        if (!$cart || !$cart->id) {
            $this->jsonError('No active cart');
            return;
        }

        $customer = new Customer($cart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            $this->jsonError('Invalid customer');
            return;
        }

        $operationNumber = $this->context->cookie->payme_operation_number ?? '';
        $selectedMethod = $this->context->cookie->payme_selected_method ?? '';
        $total = (float) $cart->getOrderTotal(true, Cart::BOTH);
        $currency = $this->context->currency;

        // Async methods (QR, PAGOEFECTIVO, BANK_TRANSFER) → on-hold / pending
        $asyncMethods = ['QR', 'PAGOEFECTIVO', 'BANK_TRANSFER'];
        $isAsync = in_array(strtoupper($selectedMethod), $asyncMethods);

        // PS_OS_CHEQUE = "Awaiting check payment" (used as on-hold equivalent)
        $orderStatus = $isAsync
            ? (int) Configuration::get('PS_OS_CHEQUE')
            : (int) Configuration::get('PS_OS_PAYMENT');
        $transactionStatus = $isAsync ? 'pending' : 'completed';

        try {
            // Build payment method display name
            $methodLabel = $selectedMethod ? $this->getMethodDisplayName($selectedMethod) : '';
            $paymentName = $this->module->displayName . ($methodLabel ? ' — ' . $methodLabel : '');

            // Validate order
            $this->module->validateOrder(
                (int) $cart->id,
                $orderStatus,
                $total,
                $paymentName,
                'Payme operation: ' . $operationNumber . ($selectedMethod ? ' [' . $selectedMethod . ']' : ''),
                ['transaction_id' => $operationNumber],
                (int) $currency->id,
                false,
                $customer->secure_key
            );

            $orderId = $this->module->currentOrder;

            // Update transaction
            $this->module->updateTransactionStatus(
                $operationNumber,
                $transactionStatus,
                $orderId,
                $resultJson
            );

            $this->module->logMessage("Order {$orderId} created for operation {$operationNumber}", 'info');

            // Return redirect URL
            $confirmUrl = $this->context->link->getPageLink(
                'order-confirmation',
                true,
                null,
                [
                    'id_cart' => (int) $cart->id,
                    'id_module' => (int) $this->module->id,
                    'id_order' => $orderId,
                    'key' => $customer->secure_key,
                ]
            );

            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'redirect' => $confirmUrl,
            ]);
            exit;

        } catch (Exception $e) {
            $this->module->logMessage('Order creation error: ' . $e->getMessage(), 'error');
            $this->jsonError('Error creating order: ' . $e->getMessage());
        }
    }

    private function processRedirectReturn()
    {
        // Handle redirect from Payme after payment
        $operationNumber = Tools::getValue('merchant_operation_number', '');
        $status = Tools::getValue('status', '');

        if (empty($operationNumber)) {
            Tools::redirect('index.php?controller=order&step=1');
            return;
        }

        // Look up transaction
        $transaction = $this->module->getTransactionByOperation($operationNumber);

        if (!$transaction) {
            $this->module->logMessage("Redirect: transaction not found for {$operationNumber}", 'error');
            Tools::redirect('index.php?controller=order&step=1');
            return;
        }

        // If order already created, redirect to confirmation
        if ((int) $transaction['id_order'] > 0) {
            $order = new Order((int) $transaction['id_order']);
            if (Validate::isLoadedObject($order)) {
                $customer = new Customer($order->id_customer);
                $confirmUrl = $this->context->link->getPageLink(
                    'order-confirmation',
                    true,
                    null,
                    [
                        'id_cart' => (int) $transaction['id_cart'],
                        'id_module' => (int) $this->module->id,
                        'id_order' => (int) $order->id,
                        'key' => $customer->secure_key,
                    ]
                );
                Tools::redirect($confirmUrl);
                return;
            }
        }

        // Order not yet created — create it now from redirect
        $cart = new Cart((int) $transaction['id_cart']);
        if (!Validate::isLoadedObject($cart)) {
            Tools::redirect('index.php?controller=order&step=1');
            return;
        }

        $customer = new Customer($cart->id_customer);
        $total = (float) $cart->getOrderTotal(true, Cart::BOTH);
        $currency = new Currency((int) $cart->id_currency);

        $isSuccess = false;
        $statusUpper = strtoupper((string)$status);
        if (!in_array($statusUpper, ['DENEGADO', 'INVALIDO', 'DENIED', 'REJECTED', 'FAILED'])) {
            $isSuccess = ($status === '00' || $status === 0 || in_array($statusUpper, ['AUTHORIZED', 'APPROVED', 'SUCCESS', 'AUTORIZADO']));
        }

        // Detect async methods from the saved transaction
        $asyncMethods = ['QR', 'PAGOEFECTIVO', 'BANK_TRANSFER'];
        $paymentMethod = isset($transaction['payment_method']) ? strtoupper($transaction['payment_method']) : '';
        $isAsync = in_array($paymentMethod, $asyncMethods);

        if ($isSuccess) {
            $orderStatus = $isAsync
                ? (int) Configuration::get('PS_OS_CHEQUE')
                : (int) Configuration::get('PS_OS_PAYMENT');
        } else {
            $orderStatus = Configuration::get('PS_OS_ERROR');
        }

        $transactionStatus = $isSuccess ? ($isAsync ? 'pending' : 'completed') : 'failed';

        try {
            $methodLabel = $paymentMethod ? $this->getMethodDisplayName($paymentMethod) : '';
            $paymentName = $this->module->displayName . ($methodLabel ? ' — ' . $methodLabel : '');

            $this->module->validateOrder(
                (int) $cart->id,
                $orderStatus,
                $total,
                $paymentName,
                'Payme operation: ' . $operationNumber,
                ['transaction_id' => $operationNumber],
                (int) $currency->id,
                false,
                $customer->secure_key
            );

            $orderId = $this->module->currentOrder;
            $this->module->updateTransactionStatus($operationNumber, $transactionStatus, $orderId);

            $confirmUrl = $this->context->link->getPageLink(
                'order-confirmation',
                true,
                null,
                [
                    'id_cart' => (int) $cart->id,
                    'id_module' => (int) $this->module->id,
                    'id_order' => $orderId,
                    'key' => $customer->secure_key,
                ]
            );
            Tools::redirect($confirmUrl);

        } catch (Exception $e) {
            $this->module->logMessage('Redirect order creation error: ' . $e->getMessage(), 'error');
            Tools::redirect('index.php?controller=order&step=1');
        }
    }

    private function jsonError($message)
    {
        header('Content-Type: application/json');
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => $message]);
        exit;
    }
}
