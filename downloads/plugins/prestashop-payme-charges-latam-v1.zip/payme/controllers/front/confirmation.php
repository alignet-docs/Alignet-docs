<?php
/**
 * Payme Confirmation Controller
 * Handles the order confirmation page (used as redirect_url fallback)
 */

class PaymeConfirmationModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $cartId = (int) Tools::getValue('id_cart', 0);
        $orderId = (int) Tools::getValue('id_order', 0);
        $key = Tools::getValue('key', '');

        if (!$cartId && !$orderId) {
            // Try to find order from cookie
            $operationNumber = $this->context->cookie->payme_operation_number ?? '';
            if ($operationNumber) {
                $transaction = $this->module->getTransactionByOperation($operationNumber);
                if ($transaction && (int) $transaction['id_order'] > 0) {
                    $orderId = (int) $transaction['id_order'];
                    $cartId = (int) $transaction['id_cart'];
                }
            }
        }

        if ($orderId) {
            $order = new Order($orderId);
            if (Validate::isLoadedObject($order)) {
                $customer = new Customer($order->id_customer);
                $confirmUrl = $this->context->link->getPageLink(
                    'order-confirmation',
                    true,
                    null,
                    [
                        'id_cart' => $cartId ?: (int) $order->id_cart,
                        'id_module' => (int) $this->module->id,
                        'id_order' => (int) $order->id,
                        'key' => $key ?: $customer->secure_key,
                    ]
                );
                Tools::redirect($confirmUrl);
                return;
            }
        }

        // Fallback
        Tools::redirect($this->context->link->getPageLink('index'));
    }
}
