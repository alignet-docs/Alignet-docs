<?php
/**
 * Payme AJAX Controller
 * Handles AJAX requests for payment data (nonce, payload)
 */

class PaymeAjaxModuleFrontController extends ModuleFrontController
{
    public $auth = false;
    public $ajax = true;
    public $ssl = true;

    /**
     * Use postProcess as the main entry point.
     * This runs BEFORE initContent/displayAjax and works reliably
     * across all PrestaShop 1.7.x and 8.x versions.
     */
    public function postProcess()
    {
        $cart = $this->context->cart;

        if (!$cart || !$cart->id || !$cart->id_customer) {
            $this->jsonResponse(['error' => 'No active cart or session'], 400);
            return;
        }

        $action = Tools::getValue('action', 'get_payment_data');

        if ($action === 'get_payment_data') {
            $this->getPaymentData($cart);
        } else {
            $this->jsonResponse(['error' => 'Unknown action'], 400);
        }
    }

    private function getPaymentData($cart)
    {
        $selectedMethod = Tools::getValue('selected_method', null);

        try {
            $accessToken = $this->module->getAccessToken();
            if (!$accessToken) {
                $this->module->logMessage('AJAX: getAccessToken failed', 'error');
                $this->jsonResponse(['error' => 'Error de autenticación con la pasarela.'], 500);
                return;
            }

            $nonce = $this->module->getNonce($accessToken);
            if (!$nonce) {
                $this->module->logMessage('AJAX: getNonce failed', 'error');
                $this->jsonResponse(['error' => 'Error al obtener nonce.'], 500);
                return;
            }

            $operationNumber = $this->module->generateOperationNumber();
            $payloadData = $this->module->preparePayload($cart, $operationNumber, $selectedMethod);

            try {
                $this->module->saveTransaction(
                    0,
                    (int) $cart->id,
                    $operationNumber,
                    $cart->getOrderTotal(),
                    Configuration::get('PAYME_CURRENCY'),
                    'pending',
                    $selectedMethod ?: '',
                    json_encode($payloadData['payload'])
                );
            } catch (Exception $e) {
                // Non-fatal: log but continue
                $this->module->logMessage('saveTransaction warning: ' . $e->getMessage(), 'warning');
            }

            $this->context->cookie->payme_operation_number = $operationNumber;
            $this->context->cookie->payme_cart_id = (int) $cart->id;
            $this->context->cookie->payme_selected_method = $selectedMethod ?: '';

            $this->jsonResponse([
                'success' => true,
                'nonce' => $nonce,
                'payload' => $payloadData['payload'],
                'display_settings' => [
                    'methods' => $payloadData['display_methods'],
                ],
                'operation_number' => $operationNumber,
            ]);

        } catch (Exception $e) {
            $this->module->logMessage('AJAX error: ' . $e->getMessage(), 'error');
            $this->jsonResponse(['error' => $e->getMessage()], 500);
        }
    }

    private function jsonResponse($data, $code = 200)
    {
        header('Content-Type: application/json');
        http_response_code($code);
        echo json_encode($data);
        exit;
    }
}
