<?php
/**
 * Payme S2S (Server-to-Server) Notification Controller
 * Receives async payment notifications from Alignet/Payme for QR, PagoEfectivo, etc.
 */

class PaymeS2sModuleFrontController extends ModuleFrontController
{
    /**
     * Alignet public keys for RSA SHA512 signature verification
     */
    const ALIGNET_PUBLIC_KEY_SANDBOX = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkmpsqcJzjQ45u0K7JOQJtfjXGeMXNwsaU6JDGSdKwSDGGXt1m551p2mlG0oGkmn9FPbp4E0lOQzkL/qhHB1YpTP2MqecJ7pMTonEeXOv0P6uwR9yvV5lxK17nE3+xgfcpFfxT5GAI/wZsQJ3+Lsvqh3+IcRG2Hb2BUdM5pYZFOUBGGSZWc/ULPtsFx2DSjI9peJ9kYibpaokphP+Cypz/LgKV7Yiv/TUufPiUk5gFYIad5VhRU822sTMRQ7BgS2CY4t49jqFkIiRnmPwM8fFKjPD4wvzssrqbAQvkk56XOcE9ML0iJhcIY1/xgNSiHqij0Ql1UTU5nAIJR5/paOnhQIDAQAB';

    const ALIGNET_PUBLIC_KEY_PRODUCTION = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwEAOZB5HxPxraV/SmOUCi+Y/A2tQ9djLWTJ7yx4kXzdDuy0yojZMwA+p5jUExN0ZvW78Td2d29KpmXu7hdTkn+NCx+CpufDh5aSsIl6XLwQh9D7cS+elq/TVaizQIAfNa6+z/xT3zFhMOwfWuj3tY2UKdyss7GFxnQ7BWahci2vlUUuR2wjKniN1XLQWX1gPw1kZhU4EcKcMbymSv7GA/ZJAEs9Ce6kziO8qZAj/tvIf4O3iA2GvfjPgV7tgfp3z2LHeLbxMCIrc+GMpKt9+Yg+hKfandUC3/8fXWtyff2W8iQA6uNDvJ3uG61bOMEKEJwlc1piZxiBsuQkmeGVskwIDAQAB';

    /** @var bool */
    public $auth = false;

    /** @var bool */
    public $ajax = true;

    public function initContent()
    {
        // Do not call parent — we handle everything in postProcess
    }

    public function postProcess()
    {
        // Must be POST
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo 'Method not allowed';
            exit;
        }

        // Read raw body
        $rawBody = file_get_contents('php://input');

        if (empty($rawBody)) {
            $this->module->logMessage('S2S: Empty body received', 'error');
            http_response_code(400);
            echo 'Empty body';
            exit;
        }

        // Get signature from header
        $signature = '';
        if (isset($_SERVER['HTTP_SIGNATURE'])) {
            $signature = $_SERVER['HTTP_SIGNATURE'];
        }

        if (empty($signature)) {
            $this->module->logMessage('S2S: Missing signature header', 'error');
            http_response_code(400);
            echo 'Missing signature';
            exit;
        }

        // Verify signature
        $environment = $this->module->getEnvironment();
        if (!$this->verifySignature($rawBody, $signature, $environment)) {
            $this->module->logMessage('S2S: Invalid signature', 'error');
            http_response_code(403);
            echo 'Invalid signature';
            exit;
        }

        // Parse body
        $data = json_decode($rawBody, true);

        if (!$data || !is_array($data)) {
            $this->module->logMessage('S2S: Invalid JSON body', 'error');
            http_response_code(400);
            echo 'Invalid JSON';
            exit;
        }

        $debugMode = Configuration::get('PAYME_DEBUG_MODE') == '1';
        if ($debugMode) {
            $this->module->logMessage('S2S notification received: ' . $rawBody, 'info');
        }

        // Extract fields
        $operationNumber = isset($data['merchant_operation_number']) ? $data['merchant_operation_number'] : '';
        $merchantCode = isset($data['merchant_code']) ? $data['merchant_code'] : '';
        $success = isset($data['success']) ? $data['success'] : false;
        $transactionState = isset($data['transaction']['state']) ? $data['transaction']['state'] : '';
        $transactionId = isset($data['transaction']['transaction_id']) ? $data['transaction']['transaction_id'] : '';
        $statusCode = isset($data['meta']['status']['code']) ? $data['meta']['status']['code'] : '';

        if (empty($operationNumber)) {
            $this->module->logMessage('S2S: Missing merchant_operation_number', 'error');
            http_response_code(200);
            echo 'OK';
            exit;
        }

        // Verify merchant_code
        $configMerchantCode = Configuration::get('PAYME_MERCHANT_CODE');
        if (!empty($merchantCode) && $merchantCode !== $configMerchantCode) {
            $this->module->logMessage("S2S: merchant_code mismatch. Expected: {$configMerchantCode}, Got: {$merchantCode}", 'error');
            http_response_code(200);
            echo 'OK';
            exit;
        }

        // Find transaction
        $transaction = $this->module->getTransactionByOperation($operationNumber);

        if (!$transaction) {
            $this->module->logMessage("S2S: Transaction not found for operation {$operationNumber}", 'error');
            http_response_code(200);
            echo 'OK';
            exit;
        }

        $idOrder = (int) $transaction['id_order'];
        if (!$idOrder) {
            $this->module->logMessage("S2S: No id_order for operation {$operationNumber}", 'error');
            http_response_code(200);
            echo 'OK';
            exit;
        }

        $order = new Order($idOrder);
        if (!Validate::isLoadedObject($order)) {
            $this->module->logMessage("S2S: Order not found: {$idOrder}", 'error');
            http_response_code(200);
            echo 'OK';
            exit;
        }

        // Only process if order is in awaiting/pending state
        $currentState = (int) $order->getCurrentState();
        $pendingStates = [
            (int) Configuration::get('PS_OS_CHEQUE'),     // Awaiting check (on-hold equivalent)
            (int) Configuration::get('PS_OS_BANKWIRE'),    // Awaiting bank wire
        ];

        if (!in_array($currentState, $pendingStates, true)) {
            if ($debugMode) {
                $this->module->logMessage("S2S: Order {$idOrder} already in state {$currentState}, skipping.", 'info');
            }
            http_response_code(200);
            echo 'OK';
            exit;
        }

        // Determine if payment was successful
        $isAuthorized = ($transactionState === 'AUTORIZADO')
            || ($success === true || $success === 'true')
            || ($statusCode === '00');

        if ($isAuthorized) {
            // Update order to "Payment accepted" (PS_OS_PAYMENT)
            $history = new OrderHistory();
            $history->id_order = $idOrder;
            $history->changeIdOrderState((int) Configuration::get('PS_OS_PAYMENT'), $order);
            $history->addWithemail(true);

            // Update transaction
            $this->module->updateTransactionStatus($operationNumber, 'completed', $idOrder, $rawBody);

            // Add private message
            $msg = new Message();
            $msg->id_order = $idOrder;
            $msg->private = 1;
            $msg->message = "Pago confirmado vía S2S. Transacción: {$transactionId}. Operación: {$operationNumber}";
            $msg->add();

            if ($debugMode) {
                $this->module->logMessage("S2S: Order {$idOrder} updated to payment accepted (AUTORIZADO)", 'info');
            }
        } else {
            // Payment denied
            $history = new OrderHistory();
            $history->id_order = $idOrder;
            $history->changeIdOrderState((int) Configuration::get('PS_OS_ERROR'), $order);
            $history->addWithemail(true);

            $this->module->updateTransactionStatus($operationNumber, 'failed', $idOrder, $rawBody);

            $msg = new Message();
            $msg->id_order = $idOrder;
            $msg->private = 1;
            $msg->message = "Pago denegado vía S2S. Estado: {$transactionState}. Código: {$statusCode}";
            $msg->add();

            if ($debugMode) {
                $this->module->logMessage("S2S: Order {$idOrder} marked as failed. State: {$transactionState}", 'info');
            }
        }

        // Always respond 200
        http_response_code(200);
        echo 'OK';
        exit;
    }

    /**
     * Verify RSA SHA512 signature from Alignet
     */
    private function verifySignature($rawBody, $signatureB64, $environment)
    {
        $publicKeyB64 = ($environment === 'production')
            ? self::ALIGNET_PUBLIC_KEY_PRODUCTION
            : self::ALIGNET_PUBLIC_KEY_SANDBOX;

        $pem = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($publicKeyB64, 64, "\n", true) . "\n-----END PUBLIC KEY-----";

        $publicKey = openssl_pkey_get_public($pem);
        if (!$publicKey) {
            $this->module->logMessage('S2S: Failed to parse public key', 'error');
            return false;
        }

        $signatureBin = base64_decode($signatureB64, true);
        if ($signatureBin === false) {
            $this->module->logMessage('S2S: Failed to decode base64 signature', 'error');
            return false;
        }

        $result = openssl_verify($rawBody, $signatureBin, $publicKey, OPENSSL_ALGO_SHA512);

        return ($result === 1);
    }
}
