<?php
/**
 * Payme - Pasarela de Pagos
 *
 * @author    Payme <soporte@payme.com>
 * @copyright 2024-2026 Payme
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0
 * @version   1.1.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class Payme extends PaymentModule
{
    const MODULE_VERSION = '1.1.0';
    const TABLE_TRANSACTIONS = 'payme_transactions';
    const TABLE_COUNTERS = 'payme_counters';
    const TABLE_LOGS = 'payme_logs';

    public function __construct()
    {
        $this->name = 'payme';
        $this->tab = 'payments_gateways';
        $this->version = self::MODULE_VERSION;
        $this->author = 'Payme';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => '8.99.99'];
        $this->bootstrap = true;
        $this->controllers = ['validation', 'confirmation', 'ajax', 's2s'];
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        parent::__construct();

        $this->displayName = $this->l('Payme Gateway');
        $this->description = $this->l('Acepta pagos con tarjeta, Yape, QR, transferencias bancarias y más métodos de pago.');
        $this->confirmUninstall = $this->l('¿Estás seguro de que deseas desinstalar Payme Gateway?');
    }

    /**
     * Install module
     */
    public function install()
    {
        if (!parent::install()
            || !$this->registerHook('paymentOptions')
            || !$this->registerHook('paymentReturn')
            || !$this->registerHook('displayHeader')
            || !$this->registerHook('displayOrderConfirmation')
            || !$this->registerHook('actionFrontControllerSetMedia')
            || !$this->registerHook('actionOrderStatusPostUpdate')
            || !$this->registerHook('displayAdminOrder')
            || !$this->createTables()
            || !$this->initCounter()
            || !$this->setDefaultConfig()
        ) {
            return false;
        }

        return true;
    }

    /**
     * Uninstall module
     */
    public function uninstall()
    {
        if (!parent::uninstall() || !$this->dropTables() || !$this->deleteConfig()) {
            return false;
        }

        return true;
    }

    // ─── DATABASE ───────────────────────────────────────────────

    private function createTables()
    {
        $db = Db::getInstance();
        $prefix = _DB_PREFIX_;
        $engine = _MYSQL_ENGINE_;

        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS `{$prefix}" . self::TABLE_TRANSACTIONS . "` (
            `id_transaction` INT(11) NOT NULL AUTO_INCREMENT,
            `id_order` INT(11) NOT NULL DEFAULT 0,
            `id_cart` INT(11) NOT NULL DEFAULT 0,
            `merchant_operation_number` VARCHAR(20) NOT NULL,
            `amount` DECIMAL(10,2) NOT NULL,
            `currency` VARCHAR(3) NOT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
            `payment_method` VARCHAR(30) NOT NULL DEFAULT '',
            `request_data` LONGTEXT,
            `response_data` LONGTEXT,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_transaction`),
            UNIQUE KEY `merchant_operation_number` (`merchant_operation_number`),
            KEY `id_order` (`id_order`),
            KEY `id_cart` (`id_cart`)
        ) ENGINE={$engine} DEFAULT CHARSET=utf8mb4;";

        $sql[] = "CREATE TABLE IF NOT EXISTS `{$prefix}" . self::TABLE_COUNTERS . "` (
            `id_counter` INT(11) NOT NULL AUTO_INCREMENT,
            `counter_name` VARCHAR(50) NOT NULL,
            `current_value` BIGINT(20) NOT NULL DEFAULT 0,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_counter`),
            UNIQUE KEY `counter_name` (`counter_name`)
        ) ENGINE={$engine} DEFAULT CHARSET=utf8mb4;";

        $sql[] = "CREATE TABLE IF NOT EXISTS `{$prefix}" . self::TABLE_LOGS . "` (
            `id_log` INT(11) NOT NULL AUTO_INCREMENT,
            `level` VARCHAR(20) NOT NULL,
            `message` TEXT NOT NULL,
            `context` LONGTEXT,
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_log`),
            KEY `level` (`level`),
            KEY `date_add` (`date_add`)
        ) ENGINE={$engine} DEFAULT CHARSET=utf8mb4;";

        foreach ($sql as $query) {
            if (!$db->execute($query)) {
                return false;
            }
        }

        return true;
    }

    private function dropTables()
    {
        $db = Db::getInstance();
        $prefix = _DB_PREFIX_;

        $db->execute("DROP TABLE IF EXISTS `{$prefix}" . self::TABLE_TRANSACTIONS . "`");
        $db->execute("DROP TABLE IF EXISTS `{$prefix}" . self::TABLE_COUNTERS . "`");
        $db->execute("DROP TABLE IF EXISTS `{$prefix}" . self::TABLE_LOGS . "`");

        return true;
    }

    private function initCounter()
    {
        $db = Db::getInstance();
        $prefix = _DB_PREFIX_;
        $table = $prefix . self::TABLE_COUNTERS;

        $exists = (int) $db->getValue(
            "SELECT COUNT(*) FROM `{$table}` WHERE `counter_name` = 'operation_number'"
        );

        if (!$exists) {
            return $db->insert(self::TABLE_COUNTERS, [
                'counter_name' => 'operation_number',
                'current_value' => 1,
                'date_upd' => date('Y-m-d H:i:s'),
            ]);
        }

        return true;
    }

    // ─── CONFIGURATION ──────────────────────────────────────────

    private function setDefaultConfig()
    {
        $defaults = [
            'PAYME_ENABLED' => '1',
            'PAYME_TITLE' => 'Pagar con Payme',
            'PAYME_DESCRIPTION' => 'Paga con tarjeta, Yape, QR y más métodos',
            'PAYME_ENVIRONMENT' => 'sandbox',
            'PAYME_CLIENT_ID' => '',
            'PAYME_CLIENT_SECRET' => '',
            'PAYME_MERCHANT_CODE' => '',
            'PAYME_CURRENCY' => '604',
            'PAYME_COUNTRY' => 'PE',
            'PAYME_DISPLAY_MODE' => 'embedded',
            'PAYME_PAYMENT_TYPE' => 'separado',
            'PAYME_PAYMENT_METHODS' => 'CARD,YAPE,QR,BANK_TRANSFER,CUOTEALO,PAGOEFECTIVO',
            'PAYME_REDIRECT_URL' => '',
            'PAYME_DEBUG_MODE' => '0',
            'PAYME_HIDE_ANIMATION' => '0',
        ];

        foreach ($defaults as $key => $value) {
            if (!Configuration::hasKey($key)) {
                Configuration::updateValue($key, $value);
            }
        }

        return true;
    }

    private function deleteConfig()
    {
        $keys = [
            'PAYME_ENABLED', 'PAYME_TITLE', 'PAYME_DESCRIPTION',
            'PAYME_ENVIRONMENT', 'PAYME_CLIENT_ID', 'PAYME_CLIENT_SECRET',
            'PAYME_MERCHANT_CODE', 'PAYME_CURRENCY', 'PAYME_COUNTRY',
            'PAYME_DISPLAY_MODE', 'PAYME_PAYMENT_TYPE', 'PAYME_PAYMENT_METHODS',
            'PAYME_REDIRECT_URL', 'PAYME_DEBUG_MODE', 'PAYME_HIDE_ANIMATION',
        ];

        foreach ($keys as $key) {
            Configuration::deleteByName($key);
        }

        return true;
    }

    // ─── HELPERS ─────────────────────────────────────────────────

    public function getEnvironment()
    {
        return Configuration::get('PAYME_ENVIRONMENT') ?: 'sandbox';
    }

    public function isProduction()
    {
        return $this->getEnvironment() === 'production';
    }

    public function getPaymentMethods()
    {
        $methods = Configuration::get('PAYME_PAYMENT_METHODS');
        return $methods ? explode(',', $methods) : ['CARD'];
    }

    public function getPaymentType()
    {
        return Configuration::get('PAYME_PAYMENT_TYPE') ?: 'separado';
    }

    private function getPhoneCountryCode()
    {
        $codes = [
            'PE' => '51', 'CO' => '57', 'CL' => '56', 'AR' => '54',
            'BR' => '55', 'EC' => '593', 'UY' => '598', 'PY' => '595',
            'BO' => '591', 'VE' => '58',
        ];
        $country = Configuration::get('PAYME_COUNTRY') ?: 'PE';
        return $codes[$country] ?? '51';
    }

    private function getCountryName()
    {
        $names = [
            'PE' => 'Peru', 'CO' => 'Colombia', 'CL' => 'Chile', 'AR' => 'Argentina',
            'BR' => 'Brasil', 'EC' => 'Ecuador', 'UY' => 'Uruguay', 'PY' => 'Paraguay',
            'BO' => 'Bolivia', 'VE' => 'Venezuela',
        ];
        $country = Configuration::get('PAYME_COUNTRY') ?: 'PE';
        return $names[$country] ?? 'Peru';
    }

    private function getRedirectUrl()
    {
        $url = Configuration::get('PAYME_REDIRECT_URL');
        if (!empty($url)) {
            return $url;
        }
        return $this->context->link->getModuleLink($this->name, 'confirmation', [], true);
    }

    
        public function generateOperationNumber()
    {
        $db = Db::getInstance();
        $prefix = _DB_PREFIX_;
        $table = $prefix . self::TABLE_COUNTERS;

        // Ensure counter row exists
        $exists = (int) $db->getValue(
            "SELECT COUNT(*) FROM `{$table}` WHERE `counter_name` = 'operation_number'"
        );
        if (!$exists) {
            $db->execute(
                "INSERT INTO `{$table}` (`counter_name`, `current_value`, `date_upd`) VALUES ('operation_number', 0, NOW())"
            );
        }

        // Atomic increment
        $db->execute(
            "UPDATE `{$table}` SET `current_value` = `current_value` + 1, `date_upd` = NOW() WHERE `counter_name` = 'operation_number'"
        );

        $seq = (int) $db->getValue(
            "SELECT `current_value` FROM `{$table}` WHERE `counter_name` = 'operation_number'"
        );

        // Build unique operation number: last 4 digits of timestamp + 5-digit sequence
        // This avoids collisions with WordPress which uses pure sequential numbers
        $timePart = substr(time(), -4);
        $seqPart = str_pad($seq % 100000, 5, '0', STR_PAD_LEFT);

        return $timePart . $seqPart;
    }



    public function logMessage($message, $level = 'info', $context = [])
    {
        if ($level !== 'error' && !Configuration::get('PAYME_DEBUG_MODE')) {
            return;
        }

        $db = Db::getInstance();
        $db->insert(self::TABLE_LOGS, [
            'level' => pSQL($level),
            'message' => pSQL($message),
            'context' => !empty($context) ? pSQL(json_encode($context)) : null,
            'date_add' => date('Y-m-d H:i:s'),
        ]);
    }

    public function saveTransaction($idOrder, $idCart, $operationNumber, $amount, $currency, $status, $method = '', $requestData = null, $responseData = null)
    {
        return Db::getInstance()->insert(self::TABLE_TRANSACTIONS, [
            'id_order' => (int) $idOrder,
            'id_cart' => (int) $idCart,
            'merchant_operation_number' => pSQL($operationNumber),
            'amount' => (float) $amount,
            'currency' => pSQL($currency),
            'status' => pSQL($status),
            'payment_method' => pSQL($method),
            'request_data' => $requestData ? pSQL($requestData, true) : null,
            'response_data' => $responseData ? pSQL($responseData, true) : null,
            'date_add' => date('Y-m-d H:i:s'),
            'date_upd' => date('Y-m-d H:i:s'),
        ]);
    }

    // ─── PAYME API ──────────────────────────────────────────────

    public function getAccessToken()
    {
        $url = $this->isProduction()
            ? 'https://auth.alignet.io/token'
            : 'https://auth.wip.alignet.io/token';

        $audience = $this->isProduction()
            ? 'https://api.alignet.io'
            : 'https://api.dev.alignet.io';

        $body = json_encode([
            'action' => 'authorize',
            'grant_type' => 'client_credentials',
            'audience' => $audience,
            'client_id' => Configuration::get('PAYME_CLIENT_ID'),
            'client_secret' => Configuration::get('PAYME_CLIENT_SECRET'),
            'scope' => 'create:token post:charges offline_access',
        ]);

        // Retry up to 2 times on transient failures (cold start, timeout)
        $maxRetries = 2;
        for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
            $response = $this->apiRequest($url, $body);

            if ($response && isset($response['access_token'])) {
                return $response['access_token'];
            }

            if ($attempt < $maxRetries) {
                $this->logMessage("getAccessToken attempt {$attempt} failed, retrying...", 'warning', $response ?: []);
                usleep(500000); // 500ms delay before retry
            }
        }

        $this->logMessage('Failed to get access token after retries', 'error', $response ?: []);
        return false;
    }

    public function getNonce($accessToken)
    {
        $url = $this->isProduction()
            ? 'https://auth.alignet.io/nonce'
            : 'https://auth.wip.alignet.io/nonce';

        $audience = $this->isProduction()
            ? 'https://api.alignet.io'
            : 'https://api.dev.alignet.io';

        $body = json_encode([
            'action' => 'create.nonce',
            'audience' => $audience,
            'client_id' => Configuration::get('PAYME_CLIENT_ID'),
            'scope' => 'post:charges',
        ]);

        // Retry up to 2 times on transient failures
        $maxRetries = 2;
        for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
            $response = $this->apiRequest($url, $body, $accessToken);

            if ($response && isset($response['nonce'])) {
                return $response['nonce'];
            }

            if ($attempt < $maxRetries) {
                $this->logMessage("getNonce attempt {$attempt} failed, retrying...", 'warning', $response ?: []);
                usleep(500000); // 500ms delay before retry
            }
        }

        $this->logMessage('Failed to get nonce after retries', 'error', $response ?: []);
        return false;
    }

    private function apiRequest($url, $body, $bearerToken = null)
    {
        $headers = ['Content-Type: application/json'];
        if ($bearerToken) {
            $headers[] = 'Authorization: Bearer ' . $bearerToken;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            $this->logMessage('cURL error: ' . $error, 'error', ['url' => $url]);
            return false;
        }

        if ($httpCode < 200 || $httpCode >= 300) {
            $this->logMessage("API HTTP error {$httpCode}", 'error', [
                'url' => $url,
                'http_code' => $httpCode,
                'response' => $result,
            ]);
            return false;
        }

        $data = json_decode($result, true);

        if ($data === null && !empty($result)) {
            $this->logMessage('API JSON decode error', 'error', [
                'url' => $url,
                'raw_response' => substr($result, 0, 500),
            ]);
            return false;
        }

        if (Configuration::get('PAYME_DEBUG_MODE')) {
            $this->logMessage("API {$url} [{$httpCode}]", 'debug', [
                'request' => $body,
                'response' => $data,
            ]);
        }

        return $data;
    }


    public function preparePayload($cart, $operationNumber, $selectedMethod = null)
    {
        $customer = new Customer($cart->id_customer);
        $address = new Address($cart->id_address_invoice);
        $amount = number_format($cart->getOrderTotal() * 100, 0, '', '');

        $displayMethods = $selectedMethod
            ? [$selectedMethod]
            : $this->getPaymentMethods();

        $payload = [
            'action' => 'authorize',
            'channel' => 'ecommerce',
            'merchant_code' => Configuration::get('PAYME_MERCHANT_CODE'),
            'merchant_operation_number' => $operationNumber,
            'payment_method' => [
                'method_details' => [
                    'callback_url' => '',
                    'redirect_url' => $this->getRedirectUrl(),
                ],
            ],
            'payment_details' => [
                'amount' => $amount,
                'currency' => Configuration::get('PAYME_CURRENCY'),
                'additional_fields' => [
                    'cms' => 'prestashop',
                    'cms_version' => defined('_PS_VERSION_') ? _PS_VERSION_ : '',
                    'platform' => 'prestashop',
                    'php_version' => PHP_VERSION,
                    'plugin_version' => self::MODULE_VERSION,
                    'tipo' => Configuration::get('PAYME_DISPLAY_MODE') ?: 'embedded',
                ],
                'billing' => [
                    'first_name' => $customer->firstname,
                    'last_name' => $customer->lastname,
                    'email' => $customer->email,
                    'phone' => [
                        'country_code' => $this->getPhoneCountryCode(),
                        'subscriber' => preg_replace('/[^0-9]/', '', $address->phone ?: $address->phone_mobile),
                    ],
                    'location' => [
                        'line_1' => $address->address1,
                        'line_2' => $address->address2 ?: '',
                        'city' => $address->city,
                        'state' => State::getNameById($address->id_state) ?: '',
                        'country' => $this->getCountryName(),
                        'zip_code' => $address->postcode ?: '',
                    ],
                ],
            ],
        ];

        return [
            'payload' => $payload,
            'display_methods' => $displayMethods,
        ];
    }

    // ─── ADMIN CONFIGURATION ────────────────────────────────────

    private function isPhpSecurityCompliant()
    {
        $minimums = array(
            '8.2' => 80235,
            '8.3' => 80336,
            '8.4' => 80427,
            '8.5' => 80512,
        );
        $branch = PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION;

        return isset($minimums[$branch]) && PHP_VERSION_ID >= $minimums[$branch];
    }

    private function renderPhpSecurityNotice()
    {
        if ($this->isPhpSecurityCompliant()) {
            return '';
        }

        return '<div id="payme-prestashop-php-security-modal" style="position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;">'
            . '<div role="dialog" aria-modal="true" style="background:#fff;border-top:8px solid #d63638;border-radius:6px;max-width:680px;width:100%;padding:30px;box-shadow:0 12px 40px rgba(0,0,0,.35);font-size:16px;">'
            . '<h1 style="margin:0 0 16px;color:#b32d2e;font-size:26px;">Actualización de seguridad obligatoria</h1>'
            . '<p>Este servidor ejecuta PHP <strong>' . htmlspecialchars(PHP_VERSION, ENT_QUOTES, 'UTF-8') . '</strong>, una versión que no cumple la política de seguridad recomendada para Pay-me.</p>'
            . '<p>Actualiza a PHP 8.2.35 o superior cuando sea posible. Los pagos existentes no se bloquearán, pero continuar puede exponer el comercio a vulnerabilidades conocidas.</p>'
            . '<label style="display:block;margin:24px 0;font-weight:600;"><input type="checkbox" id="payme-prestashop-php-security-ack" style="margin-right:8px;"> Reconozco el riesgo y deseo continuar bajo mi responsabilidad.</label>'
            . '<button type="button" id="payme-prestashop-php-security-continue" disabled style="background:#2271b1;color:#fff;border:0;border-radius:4px;padding:12px 20px;font-size:16px;cursor:pointer;">Continuar bajo mi responsabilidad</button>'
            . '<p style="margin:16px 0 0;color:#646970;font-size:13px;">Esta aceptación no se guarda en la base de datos. El aviso volverá a aparecer al recargar mientras PHP siga inseguro.</p>'
            . '</div></div>'
            . '<script>(function(){var modal=document.getElementById("payme-prestashop-php-security-modal"),check=document.getElementById("payme-prestashop-php-security-ack"),button=document.getElementById("payme-prestashop-php-security-continue");if(!modal||!check||!button)return;document.body.style.overflow="hidden";check.addEventListener("change",function(){button.disabled=!check.checked;button.style.opacity=check.checked?"1":".55";});button.addEventListener("click",function(){if(check.checked){modal.style.display="none";document.body.style.overflow="";}});})();</script>';
    }

    private function postProcess()
    {
        $output = '';
        $fields = [
            'PAYME_ENABLED', 'PAYME_TITLE', 'PAYME_DESCRIPTION',
            'PAYME_ENVIRONMENT', 'PAYME_CLIENT_ID', 'PAYME_CLIENT_SECRET',
            'PAYME_MERCHANT_CODE', 'PAYME_CURRENCY', 'PAYME_COUNTRY',
            'PAYME_DISPLAY_MODE', 'PAYME_PAYMENT_TYPE',
            'PAYME_DEBUG_MODE', 'PAYME_HIDE_ANIMATION',
        ];

        foreach ($fields as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }

        // Payment methods order from sortable UI
        $methodsOrder = Tools::getValue('PAYME_PAYMENT_METHODS_ORDER');
        if (!empty($methodsOrder)) {
            Configuration::updateValue('PAYME_PAYMENT_METHODS', $methodsOrder);
        }

        // Auto-generate redirect URL
        $redirectUrl = $this->context->link->getModuleLink($this->name, 'confirmation', [], true);
        Configuration::updateValue('PAYME_REDIRECT_URL', $redirectUrl);

        $output .= $this->displayConfirmation($this->l('Configuración guardada correctamente.'));

        $token = $this->getAccessToken();
        if ($token) {
            $output .= $this->displayConfirmation($this->l('✓ Conexión con API Payme exitosa.'));
        } else {
            $output .= $this->displayError($this->l('✗ No se pudo conectar con la API de Payme. Verifica tus credenciales.'));
        }

        return $output;
    }

    private function renderForm()
    {
        $token = Tools::getAdminTokenLite('AdminModules');
        $actionUrl = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name
            . '&token=' . $token;

        $v = $this->getConfigFormValues();
        $methods = Configuration::get('PAYME_PAYMENT_METHODS');
        $selectedMethods = $methods ? explode(',', $methods) : ['CARD'];

        $allMethods = [
            'CARD' => 'Tarjeta de Crédito/Débito',
            'YAPE' => 'Yape',
            'QR' => 'Código QR',
            'BANK_TRANSFER' => 'Transferencia Bancaria',
            'CUOTEALO' => 'Cuotéalo BCP',
            'PAGOEFECTIVO' => 'PagoEfectivo',
        ];

        $orderedKeys = [];
        foreach ($selectedMethods as $m) {
            if (isset($allMethods[$m])) {
                $orderedKeys[] = $m;
            }
        }
        foreach (array_keys($allMethods) as $m) {
            if (!in_array($m, $orderedKeys)) {
                $orderedKeys[] = $m;
            }
        }

        $redirectUrl = Configuration::get('PAYME_REDIRECT_URL');
        if (empty($redirectUrl)) {
            $redirectUrl = $this->context->link->getModuleLink($this->name, 'confirmation', [], true);
        }

        $countries = [
            'PE' => 'Perú', 'CO' => 'Colombia', 'CL' => 'Chile', 'AR' => 'Argentina',
            'BR' => 'Brasil', 'EC' => 'Ecuador', 'UY' => 'Uruguay', 'PY' => 'Paraguay',
            'BO' => 'Bolivia', 'VE' => 'Venezuela',
        ];
        $currencies = [
            '604' => 'PEN - Sol Peruano', '840' => 'USD - Dólar Americano', '978' => 'EUR - Euro',
            '170' => 'COP - Peso Colombiano', '152' => 'CLP - Peso Chileno',
            '032' => 'ARS - Peso Argentino', '986' => 'BRL - Real Brasileño',
        ];

        $html = '<form method="post" action="' . htmlspecialchars($actionUrl) . '" class="payme-config-form">';
        $html .= '<input type="hidden" name="submitPaymeModule" value="1">';
        $html .= '<input type="hidden" name="PAYME_PAYMENT_METHODS_ORDER" id="payme_methods_order" value="' . htmlspecialchars(implode(',', $selectedMethods)) . '">';

        $checked = ($v['PAYME_ENABLED'] ?? '1') == '1' ? 'checked' : '';
        $html .= $this->adminField('Habilitar', '<label class="payme-switch"><input type="hidden" name="PAYME_ENABLED" value="0"><input type="checkbox" name="PAYME_ENABLED" value="1" ' . $checked . '><span class="payme-slider"></span></label>');

        $html .= $this->adminField('Título', '<input type="text" name="PAYME_TITLE" value="' . htmlspecialchars($v['PAYME_TITLE'] ?? '') . '" class="payme-input payme-input--full">', 'Título que verá el usuario durante el checkout.');

        $html .= $this->adminField('Descripción', '<textarea name="PAYME_DESCRIPTION" class="payme-input payme-input--full" rows="2">' . htmlspecialchars($v['PAYME_DESCRIPTION'] ?? '') . '</textarea>', 'Descripción que verá el usuario durante el checkout.');

        $countrySelect = '<select name="PAYME_COUNTRY" class="payme-input payme-input--full">';
        foreach ($countries as $code => $name) {
            $sel = ($v['PAYME_COUNTRY'] ?? 'PE') === $code ? 'selected' : '';
            $countrySelect .= '<option value="' . $code . '" ' . $sel . '>' . $name . '</option>';
        }
        $countrySelect .= '</select>';
        $html .= $this->adminField('País', $countrySelect);

        $envVal = $v['PAYME_ENVIRONMENT'] ?? 'sandbox';
        $envHtml = '<div class="payme-radio-group">';
        $envHtml .= '<label class="payme-radio-card' . ($envVal === 'sandbox' ? ' active' : '') . '"><input type="radio" name="PAYME_ENVIRONMENT" value="sandbox" ' . ($envVal === 'sandbox' ? 'checked' : '') . '> Sandbox (Pruebas)</label>';
        $envHtml .= '<label class="payme-radio-card payme-radio-card--danger' . ($envVal === 'production' ? ' active' : '') . '"><input type="radio" name="PAYME_ENVIRONMENT" value="production" ' . ($envVal === 'production' ? 'checked' : '') . '> Producción ⚠️</label>';
        $envHtml .= '</div>';
        $html .= $this->adminField('Ambiente', $envHtml);

        $dmVal = $v['PAYME_DISPLAY_MODE'] ?? 'embedded';
        $dmSelect = '<select name="PAYME_DISPLAY_MODE" class="payme-input payme-input--full">';
        $dmSelect .= '<option value="embedded" ' . ($dmVal === 'embedded' ? 'selected' : '') . '>Embebido en el checkout</option>';
        $dmSelect .= '<option value="popup" ' . ($dmVal === 'popup' ? 'selected' : '') . '>Ventana emergente (popup)</option>';
        $dmSelect .= '</select>';
        $html .= $this->adminField('Modo de Visualización', $dmSelect);

        $html .= $this->adminField('Client ID', '<input type="text" name="PAYME_CLIENT_ID" value="' . htmlspecialchars($v['PAYME_CLIENT_ID'] ?? '') . '" class="payme-input payme-input--full">', 'Client ID proporcionado por Payme.');

        $html .= $this->adminField('Client Secret', '<input type="text" name="PAYME_CLIENT_SECRET" value="' . htmlspecialchars($v['PAYME_CLIENT_SECRET'] ?? '') . '" class="payme-input payme-input--full payme-input--secret" autocomplete="off">', 'Client Secret proporcionado por Payme.');

        $html .= $this->adminField('Merchant Code', '<input type="text" name="PAYME_MERCHANT_CODE" value="' . htmlspecialchars($v['PAYME_MERCHANT_CODE'] ?? '') . '" class="payme-input payme-input--full">', 'Código de comercio proporcionado por Payme.');

        $currSelect = '<select name="PAYME_CURRENCY" class="payme-input payme-input--full">';
        foreach ($currencies as $code => $name) {
            $sel = ($v['PAYME_CURRENCY'] ?? '604') === $code ? 'selected' : '';
            $currSelect .= '<option value="' . $code . '" ' . $sel . '>' . $name . '</option>';
        }
        $currSelect .= '</select>';
        $html .= $this->adminField('Moneda', $currSelect);

        $ptVal = $v['PAYME_PAYMENT_TYPE'] ?? 'separado';
        $ptHtml = '<div class="payme-radio-group">';
        $ptHtml .= '<label class="payme-radio-card' . ($ptVal === 'junto' ? ' active' : '') . '"><input type="radio" name="PAYME_PAYMENT_TYPE" value="junto" ' . ($ptVal === 'junto' ? 'checked' : '') . '> Junto (un solo gateway)</label>';
        $ptHtml .= '<label class="payme-radio-card' . ($ptVal === 'separado' ? ' active' : '') . '"><input type="radio" name="PAYME_PAYMENT_TYPE" value="separado" ' . ($ptVal === 'separado' ? 'checked' : '') . '> Separado (un gateway por método)</label>';
        $ptHtml .= '</div>';
        $html .= $this->adminField('Tipo de Visualización', $ptHtml);

        $methodsHtml = '<div class="payme-sortable-methods" id="payme-sortable-methods">';
        foreach ($orderedKeys as $key) {
            $isChecked = in_array($key, $selectedMethods) ? 'checked' : '';
            $methodsHtml .= '<div class="payme-sortable-item" data-value="' . $key . '">';
            $methodsHtml .= '<span class="payme-drag-handle">☰</span>';
            $methodsHtml .= '<label><input type="checkbox" value="' . $key . '" ' . $isChecked . '> ' . $allMethods[$key] . '</label>';
            $methodsHtml .= '</div>';
        }
        $methodsHtml .= '</div>';
        $html .= $this->adminField('Métodos de Pago (arrastra para ordenar)', $methodsHtml, 'Selecciona y ordena los métodos. El orden aquí será el orden en el checkout.');

        $html .= $this->adminField('Redirect URL', '<input type="text" value="' . htmlspecialchars($redirectUrl) . '" class="payme-input payme-input--full" readonly style="background:#f1f5f9;color:#64748b;">', 'Se genera automáticamente.');

        $s2sUrl = $this->context->link->getModuleLink($this->name, 's2s', [], true);
        $html .= $this->adminField('URL S2S (Notificación Server-to-Server)', '<input type="text" value="' . htmlspecialchars($s2sUrl) . '" class="payme-input payme-input--full" readonly style="background:#f1f5f9;color:#64748b;" onclick="this.select();">', 'URL para recibir notificaciones de pago asíncronas (QR, PagoEfectivo). Copia esta URL y pásala a Payme.');

        $debugChecked = ($v['PAYME_DEBUG_MODE'] ?? '0') == '1' ? 'checked' : '';
        $html .= $this->adminField('Modo Debug', '<label class="payme-switch"><input type="hidden" name="PAYME_DEBUG_MODE" value="0"><input type="checkbox" name="PAYME_DEBUG_MODE" value="1" ' . $debugChecked . '><span class="payme-slider"></span></label>', 'Habilitar logs detallados.');

        $hideAnimVal = $v['PAYME_HIDE_ANIMATION'] ?? '0';
        $hideAnimHtml = '<div class="payme-radio-group">';
        $hideAnimHtml .= '<label class="payme-radio-card' . ($hideAnimVal === '1' ? ' active' : '') . '"><input type="radio" name="PAYME_HIDE_ANIMATION" value="1" ' . ($hideAnimVal === '1' ? 'checked' : '') . '> Sí</label>';
        $hideAnimHtml .= '<label class="payme-radio-card' . ($hideAnimVal !== '1' ? ' active' : '') . '"><input type="radio" name="PAYME_HIDE_ANIMATION" value="0" ' . ($hideAnimVal !== '1' ? 'checked' : '') . '> No</label>';
        $hideAnimHtml .= '</div>';
        $html .= $this->adminField('Ocultar animación', $hideAnimHtml, 'Oculta la pantalla de resultado/animación del SDK Flex después del pago.');

        $html .= '<div class="payme-form-footer"><button type="submit" class="payme-btn-save"><i class="icon-save"></i> Guardar</button></div>';
        $html .= '</form>';
        $html .= $this->getAdminSortableJs();

        return $html;
    }

    private function adminField($label, $input, $desc = '')
    {
        $h = '<div class="payme-field"><label class="payme-field__label">' . $label . '</label>';
        $h .= '<div class="payme-field__input">' . $input;
        if ($desc) {
            $h .= '<p class="payme-field__desc">' . $desc . '</p>';
        }
        return $h . '</div></div>';
    }

    private function getAdminSortableJs()
    {
        return '<script>
(function(){
    var w=document.getElementById("payme-sortable-methods");if(!w)return;
    var oi=document.getElementById("payme_methods_order"),ds=null;
    var methodsRow=w.closest(".payme-field");
    function sync(){var v=[];w.querySelectorAll(".payme-sortable-item").forEach(function(e){if(e.querySelector("input[type=checkbox]").checked)v.push(e.dataset.value);});oi.value=v.join(",");}
    function toggleMethodsVisibility(){var pt=document.querySelector("input[name=PAYME_PAYMENT_TYPE]:checked");if(methodsRow){methodsRow.style.display=(pt&&pt.value==="junto")?"none":"";}}
    w.addEventListener("change",sync);
    w.querySelectorAll(".payme-drag-handle").forEach(function(h){h.addEventListener("mousedown",function(){h.closest(".payme-sortable-item").draggable=true;});});
    w.addEventListener("dragstart",function(e){var i=e.target.closest(".payme-sortable-item");if(!i)return;ds=i;i.classList.add("dragging");e.dataTransfer.effectAllowed="move";e.dataTransfer.setData("text/plain","");});
    w.addEventListener("dragover",function(e){e.preventDefault();var i=e.target.closest(".payme-sortable-item");if(!i||i===ds)return;var r=i.getBoundingClientRect(),m=r.top+r.height/2;i.classList.remove("drag-above","drag-below");i.classList.add(e.clientY<m?"drag-above":"drag-below");});
    w.addEventListener("dragleave",function(e){var i=e.target.closest(".payme-sortable-item");if(i)i.classList.remove("drag-above","drag-below");});
    w.addEventListener("drop",function(e){e.preventDefault();var i=e.target.closest(".payme-sortable-item");if(!i||i===ds)return;i.classList.remove("drag-above","drag-below");var r=i.getBoundingClientRect();if(e.clientY<r.top+r.height/2)i.before(ds);else i.after(ds);sync();});
    w.addEventListener("dragend",function(e){var i=e.target.closest(".payme-sortable-item");if(i){i.classList.remove("dragging");i.draggable=false;}w.querySelectorAll(".payme-sortable-item").forEach(function(el){el.classList.remove("drag-above","drag-below");});});
    document.querySelectorAll(".payme-radio-card input[type=radio]").forEach(function(r){r.addEventListener("change",function(){var g=this.closest(".payme-radio-group");g.querySelectorAll(".payme-radio-card").forEach(function(c){c.classList.remove("active");});this.closest(".payme-radio-card").classList.add("active");if(this.name==="PAYME_PAYMENT_TYPE")toggleMethodsVisibility();});});
    sync();
    toggleMethodsVisibility();
})();
</script>';
    }

    private function getConfigFormValues()
    {
        return [
            'PAYME_ENABLED' => Configuration::get('PAYME_ENABLED'),
            'PAYME_TITLE' => Configuration::get('PAYME_TITLE'),
            'PAYME_DESCRIPTION' => Configuration::get('PAYME_DESCRIPTION'),
            'PAYME_ENVIRONMENT' => Configuration::get('PAYME_ENVIRONMENT'),
            'PAYME_CLIENT_ID' => Configuration::get('PAYME_CLIENT_ID'),
            'PAYME_CLIENT_SECRET' => Configuration::get('PAYME_CLIENT_SECRET'),
            'PAYME_MERCHANT_CODE' => Configuration::get('PAYME_MERCHANT_CODE'),
            'PAYME_CURRENCY' => Configuration::get('PAYME_CURRENCY'),
            'PAYME_COUNTRY' => Configuration::get('PAYME_COUNTRY'),
            'PAYME_DISPLAY_MODE' => Configuration::get('PAYME_DISPLAY_MODE'),
            'PAYME_PAYMENT_TYPE' => Configuration::get('PAYME_PAYMENT_TYPE'),
            'PAYME_REDIRECT_URL' => Configuration::get('PAYME_REDIRECT_URL'),
            'PAYME_DEBUG_MODE' => Configuration::get('PAYME_DEBUG_MODE'),
            'PAYME_HIDE_ANIMATION' => Configuration::get('PAYME_HIDE_ANIMATION'),
        ];
    }

    // ─── HOOKS ──────────────────────────────────────────────────

    /**
     * Hook: paymentOptions — Register payment option(s) in checkout
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active || !Configuration::get('PAYME_ENABLED')) {
            return [];
        }

        $methods = $this->getPaymentMethods();
        $paymentType = $this->getPaymentType();

        // Always show a single "Pagar con Payme" option with methods inside (like WooCommerce)
        $option = new \PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $option->setModuleName($this->name)
            ->setCallToActionText(Configuration::get('PAYME_TITLE') ?: $this->l('Pagar con Payme'))
            ->setAction($this->context->link->getModuleLink($this->name, 'validation', [], true))
            ->setAdditionalInformation($this->generateAccordionHtml($methods, $paymentType));

        $logoPath = $this->getPathUri() . 'views/img/payme-logo.png';
        if (file_exists(_PS_MODULE_DIR_ . $this->name . '/views/img/payme-logo.png')) {
            $option->setLogo($logoPath);
        }

        return [$option];
    }

    private function getMethodLogoFile($method)
    {
        $map = [
            'CARD' => 'tarjeta.png',
            'YAPE' => 'yape.png',
            'QR' => 'qr.png',
            'BANK_TRANSFER' => 'transbank.png',
            'CUOTEALO' => 'cuotealo.png',
            'PAGOEFECTIVO' => 'pagoefectivo.png',
        ];
        $file = $map[$method] ?? null;
        if ($file && file_exists(_PS_MODULE_DIR_ . $this->name . '/views/img/methods/' . $file)) {
            return $file;
        }
        return null;
    }

    
        private function generateAccordionHtml($methods, $paymentType)
        {
            $methodNames = [
                'CARD' => 'Tarjeta de Crédito/Débito',
                'YAPE' => 'Yape',
                'QR' => 'Código QR',
                'BANK_TRANSFER' => 'Transferencia Bancaria',
                'CUOTEALO' => 'Cuotéalo BCP',
                'PAGOEFECTIVO' => 'PagoEfectivo',
            ];

            $displayMode = Configuration::get('PAYME_DISPLAY_MODE') ?: 'embedded';

            if ($paymentType === 'junto' || count($methods) === 1) {
                if ($displayMode === 'popup') {
                    // Junto + Modal: show a "Pagar" button instead of embedded form
                    return '<div class="payme-checkout-container">'
                        . '<div id="payme-flex-container" class="payme-embedded-form" style="display:none;"></div>'
                        . '<button type="button" id="payme-popup-pay-btn" class="payme-popup-pay-btn"'
                        . ' style="display:block;width:100%;padding:14px 24px;margin:12px 0;'
                        . 'background:linear-gradient(135deg,#3b82f6 0%,#2563eb 100%);color:#fff;border:none;'
                        . 'border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;text-align:center;'
                        . 'box-shadow:0 2px 8px rgba(59,130,246,0.3);transition:all 0.2s ease;">'
                        . '💳 Pagar con Payme</button>'
                        . '</div>';
                }
                // Junto + Embedded: single Flex container
                return '<div class="payme-checkout-container">'
                    . '<div id="payme-flex-container" class="payme-embedded-form payme-loading">'
                    . 'Cargando pasarela de pago...'
                    . '</div>'
                    . '</div>';
            }

            // Separado: accordion with one method per item
            $html = '<div class="payme-accordion">';
            $html .= '<p class="payme-accordion__title">Selecciona el medio de Pago</p>';

            foreach ($methods as $method) {
                $name = $methodNames[$method] ?? $method;
                $logoFile = $this->getMethodLogoFile($method);
                $logoUrl = $logoFile ? $this->getPathUri() . 'views/img/methods/' . $logoFile : '';

                $html .= '<div class="payme-accordion__item" data-method="' . htmlspecialchars($method) . '">';
                $html .= '<label class="payme-accordion__header">';
                $html .= '<input type="radio" name="payme_selected_method" value="' . htmlspecialchars($method) . '" class="payme-accordion__radio">';
                if ($logoUrl) {
                    $html .= '<img src="' . htmlspecialchars($logoUrl) . '" alt="' . htmlspecialchars($name) . '" class="payme-accordion__logo">';
                }
                $html .= '<span class="payme-accordion__name">' . htmlspecialchars($name) . '</span>';
                $html .= '</label>';
                $html .= '<div class="payme-accordion__body" style="display:none;">';
                $html .= '<div id="payme-flex-' . htmlspecialchars($method) . '" class="payme-embedded-form payme-loading">';
                $html .= 'Cargando pasarela de pago...';
                $html .= '</div>';
                $html .= '</div>';
                $html .= '</div>';
            }

            $html .= '</div>';
            return $html;
        }


    /**
     * Hook: paymentReturn — Order confirmation after payment
     */
    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return '';
        }

        // PS 1.7+
        $order = isset($params['order']) ? $params['order'] : null;
        if (!$order) {
            return '';
        }

        $currentState = (int) $order->getCurrentState();
        $isError = ($currentState === (int) Configuration::get('PS_OS_ERROR'));

        $this->smarty->assign([
            'shop_name' => $this->context->shop->name,
            'order_reference' => $order->reference,
            'order_total' => Tools::displayPrice($order->total_paid, (int) $order->id_currency),
            'status' => $currentState,
            'status_name' => $order->getCurrentOrderState()->name[$this->context->language->id] ?? '',
            'is_error' => $isError,
        ]);

        return $this->display(__FILE__, 'views/templates/hook/confirmation.tpl');
    }

    /**
     * Hook: actionFrontControllerSetMedia — Enqueue CSS/JS on frontend
     */
    public function hookActionFrontControllerSetMedia($params)
    {
        if (!$this->active || !Configuration::get('PAYME_ENABLED')) {
            return;
        }

        // Only load on checkout and order confirmation pages
        $controller = Tools::getValue('controller');
        $isCheckout = in_array($controller, ['order', 'orderopc']);
        $isConfirmation = $controller === 'order-confirmation';

        if (!$isCheckout && !$isConfirmation) {
            return;
        }

        // Flex SDK
        $env = $this->getEnvironment();
        if ($env === 'production') {
            $this->context->controller->registerJavascript('payme-flex-sdk', 'https://flex.alignet.io/flex-payment-forms.min.js', ['server' => 'remote', 'position' => 'bottom', 'priority' => 100]);
            $this->context->controller->registerStylesheet('payme-flex-css', 'https://flex.alignet.io/main-flex-payment-forms.css', ['server' => 'remote', 'priority' => 100]);
        } else {
            $this->context->controller->registerJavascript('payme-flex-sdk', 'https://alignet-flex-demo.s3.amazonaws.com/flex-payment-forms.min.js', ['server' => 'remote', 'position' => 'bottom', 'priority' => 100]);
            $this->context->controller->registerStylesheet('payme-flex-css', 'https://alignet-flex-demo.s3.amazonaws.com/main-flex-payment-forms.css', ['server' => 'remote', 'priority' => 100]);
        }

        if ($isCheckout) {
            // Checkout CSS
            $this->context->controller->registerStylesheet('payme-styles', 'modules/' . $this->name . '/views/css/payme-styles.css', ['media' => 'all', 'priority' => 200]);
            $this->context->controller->registerStylesheet('payme-methods', 'modules/' . $this->name . '/views/css/payme-methods.css', ['media' => 'all', 'priority' => 201]);

            // Checkout JS
            $this->context->controller->registerJavascript('payme-checkout', 'modules/' . $this->name . '/views/js/payme-checkout.js', ['position' => 'bottom', 'priority' => 200]);

            // Pass config to JS
            Media::addJsDef([
                'payme_config' => [
                    'ajax_url' => $this->context->link->getModuleLink($this->name, 'ajax', [], true),
                    'validation_url' => $this->context->link->getModuleLink($this->name, 'validation', [], true),
                    'checkout_url' => $this->context->link->getPageLink('order', true),
                    'environment' => $env,
                    'display_mode' => Configuration::get('PAYME_DISPLAY_MODE') ?: 'embedded',
                    'payment_type' => $this->getPaymentType(),
                    'payment_methods' => $this->getPaymentMethods(),
                    'hide_animation' => Configuration::get('PAYME_HIDE_ANIMATION') === '1' ? 'yes' : 'no',
                    'module_name' => $this->name,
                    'plugin_url' => $this->getPathUri(),
                    'messages' => [
                        'loading' => $this->l('Cargando pasarela de pago...'),
                        'error' => $this->l('Error al procesar el pago. Inténtalo nuevamente.'),
                        'popup_blocked' => $this->l('El popup fue bloqueado. Por favor, permite popups para este sitio.'),
                    ],
                ],
            ]);
        }

        if ($isConfirmation) {
            $this->context->controller->registerStylesheet('payme-order-received', 'modules/' . $this->name . '/views/css/payme-order-received.css', ['media' => 'all', 'priority' => 200]);
            $this->context->controller->registerJavascript('payme-order-received', 'modules/' . $this->name . '/views/js/payme-order-received.js', ['position' => 'bottom', 'priority' => 200]);

            // Pass order status to JS for pending banner detection
            $orderStatus = '';
            $idOrder = (int) Tools::getValue('id_order');
            if ($idOrder) {
                $order = new Order($idOrder);
                if (Validate::isLoadedObject($order)) {
                    $currentState = (int) $order->getCurrentState();
                    $pendingStates = [
                        (int) Configuration::get('PS_OS_CHEQUE'),
                        (int) Configuration::get('PS_OS_BANKWIRE'),
                    ];
                    $orderStatus = in_array($currentState, $pendingStates) ? 'pending' : 'completed';
                    if ($currentState === (int) Configuration::get('PS_OS_ERROR')) {
                        $orderStatus = 'error';
                    }
                }
            }
            Media::addJsDef([
                'payme_order' => [
                    'status' => $orderStatus,
                ],
            ]);
        }
    }

    /**
     * Hook: displayOrderConfirmation — Enhanced confirmation banner
     */
    public function hookDisplayOrderConfirmation($params)
    {
        if (!$this->active) {
            return '';
        }

        $order = isset($params['order']) ? $params['order'] : null;
        if (!$order || $order->module !== $this->name) {
            return '';
        }

        // Detect pending states (PS_OS_CHEQUE = awaiting payment, used for async methods)
        $currentState = (int) $order->getCurrentState();
        $pendingStates = [
            (int) Configuration::get('PS_OS_CHEQUE'),
            (int) Configuration::get('PS_OS_BANKWIRE'),
        ];
        $isPending = in_array($currentState, $pendingStates);
        $isError = ($currentState === (int) Configuration::get('PS_OS_ERROR'));

        $this->smarty->assign([
            'order_reference' => $order->reference,
            'order_total' => Tools::displayPrice($order->total_paid, (int) $order->id_currency),
            'payme_is_pending' => $isPending,
            'payme_is_error' => $isError,
        ]);

        return $this->display(__FILE__, 'views/templates/hook/order_confirmation_banner.tpl');
    }

    // ─── UTILITY ────────────────────────────────────────────────

    /**
     * Update transaction status
     */
    public function updateTransactionStatus($operationNumber, $status, $idOrder = null, $responseData = null)
    {
        $data = [
            'status' => pSQL($status),
            'date_upd' => date('Y-m-d H:i:s'),
        ];
        if ($idOrder !== null) {
            $data['id_order'] = (int) $idOrder;
        }
        if ($responseData !== null) {
            $data['response_data'] = pSQL($responseData, true);
        }

        return Db::getInstance()->update(
            self::TABLE_TRANSACTIONS,
            $data,
            "merchant_operation_number = '" . pSQL($operationNumber) . "'"
        );
    }

    /**
     * Get transaction by operation number
     */
    public function getTransactionByOperation($operationNumber)
    {
        return Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . self::TABLE_TRANSACTIONS
            . "` WHERE `merchant_operation_number` = '" . pSQL($operationNumber) . "'"
        );
    }

    /**
     * Get transaction by order ID (for refunds)
     */
    public function getTransactionByOrderId($idOrder)
    {
        $db = Db::getInstance();
        $table = _DB_PREFIX_ . self::TABLE_TRANSACTIONS;

        // Try completed or pending first
        $row = $db->getRow(
            "SELECT * FROM `{$table}` WHERE `id_order` = " . (int) $idOrder
            . " AND `status` IN ('completed','pending') ORDER BY `date_add` DESC"
        );

        if (!$row) {
            // Fallback: any non-refunded
            $row = $db->getRow(
                "SELECT * FROM `{$table}` WHERE `id_order` = " . (int) $idOrder
                . " AND `status` != 'refunded' ORDER BY `date_add` DESC"
            );
        }

        return $row;
    }

    // ─── REFUND (EXTORNO) ───────────────────────────────────────

    /**
     * Process full refund via Payme DELETE API
     */
    public function processRefund($idOrder)
    {
        $transaction = $this->getTransactionByOrderId($idOrder);
        if (!$transaction) {
            return ['success' => false, 'error' => 'No se encontró una transacción para esta orden.'];
        }

        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return ['success' => false, 'error' => 'Error al obtener token de acceso para el extorno.'];
        }

        $baseUrl = $this->isProduction()
            ? 'https://api.alignet.io'
            : 'https://api.preprod.alignet.io';

        $url = $baseUrl . '/charges/' . Configuration::get('PAYME_MERCHANT_CODE') . '/' . $transaction['merchant_operation_number'];

        $this->logMessage("Refund request: DELETE {$url}", 'info', ['order_id' => $idOrder]);

        // DELETE request via cURL
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => 'DELETE',
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $accessToken,
                'ALG-API-VERSION: 1709847567',
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            $this->logMessage('Refund cURL error: ' . $error, 'error');
            return ['success' => false, 'error' => 'Error de conexión: ' . $error];
        }

        $data = json_decode($result, true);

        $this->logMessage("Refund response [{$httpCode}]", 'info', [
            'url' => $url,
            'response' => $data,
        ]);

        if ($httpCode >= 200 && $httpCode < 300) {
            // Save refund record
            $this->saveTransaction(
                (int) $idOrder,
                (int) $transaction['id_cart'],
                $transaction['merchant_operation_number'] . '_refund',
                -abs($transaction['amount']),
                $transaction['currency'],
                'refunded',
                $transaction['payment_method'],
                json_encode(['url' => $url, 'method' => 'DELETE']),
                $result
            );

            return [
                'success' => true,
                'message' => 'Extorno procesado exitosamente. Operación: ' . $transaction['merchant_operation_number'],
                'debug' => [
                    'method' => 'DELETE',
                    'url' => $url,
                    'http_code' => $httpCode,
                ],
            ];
        }

        $errorMsg = '';
        if (isset($data['message'])) {
            $errorMsg = $data['message'];
        } elseif (isset($data['error'])) {
            $errorMsg = is_string($data['error']) ? $data['error'] : json_encode($data['error']);
        }
        if (empty($errorMsg)) {
            $errorMsg = "Error del API Payme (HTTP {$httpCode})";
        }

        return [
            'success' => false,
            'error' => $errorMsg,
            'debug' => [
                'method' => 'DELETE',
                'url' => $url,
                'http_code' => $httpCode,
                'response' => $data,
            ],
        ];
    }

    /**
     * Hook: actionOrderStatusPostUpdate — Auto-refund when status changes to "Refunded"
     */
    public function hookActionOrderStatusPostUpdate($params)
    {
        $newStatus = isset($params['newOrderStatus']) ? $params['newOrderStatus'] : null;
        $idOrder = isset($params['id_order']) ? (int) $params['id_order'] : 0;

        if (!$newStatus || !$idOrder) {
            return;
        }

        // PS_OS_REFUND = "Refunded" status
        if ((int) $newStatus->id !== (int) Configuration::get('PS_OS_REFUND')) {
            return;
        }

        $order = new Order($idOrder);
        if (!Validate::isLoadedObject($order) || $order->module !== $this->name) {
            return;
        }

        // Prevent duplicate refund
        $alreadyRefunded = Db::getInstance()->getValue(
            "SELECT COUNT(*) FROM `" . _DB_PREFIX_ . self::TABLE_TRANSACTIONS . "`"
            . " WHERE `id_order` = " . (int) $idOrder . " AND `status` = 'refunded'"
        );
        if ((int) $alreadyRefunded > 0) {
            return;
        }

        $result = $this->processRefund($idOrder);

        // Add private message to order
        $msg = new Message();
        $msg->id_order = $idOrder;
        $msg->private = 1;
        $msg->message = $result['success']
            ? 'Payme: ' . $result['message']
            : 'Payme extorno error: ' . ($result['error'] ?? 'Error desconocido');
        $msg->add();
    }

    /**
     * Hook: displayAdminOrder — Show refund button in admin order page
     */
    public function hookDisplayAdminOrder($params)
    {
        $idOrder = isset($params['id_order']) ? (int) $params['id_order'] : 0;
        if (!$idOrder) {
            return '';
        }

        $order = new Order($idOrder);
        if (!Validate::isLoadedObject($order) || $order->module !== $this->name) {
            return '';
        }

        // Don't show if already refunded
        $alreadyRefunded = Db::getInstance()->getValue(
            "SELECT COUNT(*) FROM `" . _DB_PREFIX_ . self::TABLE_TRANSACTIONS . "`"
            . " WHERE `id_order` = " . (int) $idOrder . " AND `status` = 'refunded'"
        );
        if ((int) $alreadyRefunded > 0) {
            return '<div class="alert alert-info">✓ Esta orden ya fue extornada con Payme.</div>';
        }

        // Only show for paid/on-hold orders
        $currentState = (int) $order->getCurrentState();
        $allowedStates = [
            (int) Configuration::get('PS_OS_PAYMENT'),
            (int) Configuration::get('PS_OS_CHEQUE'),
            (int) Configuration::get('PS_OS_WS_PAYMENT'),
        ];
        if (!in_array($currentState, $allowedStates)) {
            return '';
        }

        $total = Tools::displayPrice($order->total_paid, (int) $order->id_currency);
        $ajaxUrl = $this->context->link->getAdminLink('AdminModules', true, [], [
            'configure' => $this->name,
            'ajax_refund' => 1,
            'id_order' => $idOrder,
        ]);
        $token = Tools::getAdminTokenLite('AdminModules');

        return '
        <div class="card mt-2" id="payme-refund-panel">
            <div class="card-header"><h3 class="card-header-title">Extorno Payme</h3></div>
            <div class="card-body">
                <p>Monto a extornar: <strong>' . $total . '</strong> (extorno completo)</p>
                <button type="button" class="btn btn-danger" id="payme-refund-btn"
                    style="background:#d63638;border-color:#d63638;">
                    Extornar con Payme (' . $total . ')
                </button>
                <div id="payme-refund-result" class="mt-2"></div>
            </div>
        </div>
        <script>
        document.getElementById("payme-refund-btn").addEventListener("click", function() {
            if (!confirm("¿Estás seguro de extornar el monto completo de ' . addslashes(strip_tags($total)) . '? Esta acción no se puede deshacer.")) return;
            var btn = this;
            btn.disabled = true;
            btn.textContent = "Procesando extorno...";
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "' . $this->context->link->getAdminLink('AdminModules') . '", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function() {
                try {
                    var resp = JSON.parse(xhr.responseText);
                    console.log("Payme refund debug:", resp.debug || resp);
                    var el = document.getElementById("payme-refund-result");
                    if (resp.success) {
                        el.innerHTML = "<div class=\\"alert alert-success\\">✓ " + resp.message + "</div>";
                        setTimeout(function(){ location.reload(); }, 1500);
                    } else {
                        el.innerHTML = "<div class=\\"alert alert-danger\\">Error: " + (resp.error || "Error desconocido") + "</div>";
                        btn.disabled = false;
                        btn.textContent = "Extornar con Payme (' . addslashes(strip_tags($total)) . ')";
                    }
                } catch(e) {
                    document.getElementById("payme-refund-result").innerHTML = "<div class=\\"alert alert-danger\\">Error de conexión</div>";
                    btn.disabled = false;
                    btn.textContent = "Extornar con Payme (' . addslashes(strip_tags($total)) . ')";
                }
            };
            xhr.send("configure=' . $this->name . '&ajax_refund=1&id_order=' . $idOrder . '&token=' . $token . '");
        });
        </script>';
    }

    /**
     * Handle AJAX refund request from admin + render config page
     */
    public function getContent()
    {
        $output = $this->renderPhpSecurityNotice();

        // Handle AJAX refund
        if (Tools::getValue('ajax_refund') && Tools::getValue('id_order')) {
            $idOrder = (int) Tools::getValue('id_order');
            $result = $this->processRefund($idOrder);

            if ($result['success']) {
                // Update order status to refunded
                $order = new Order($idOrder);
                if (Validate::isLoadedObject($order)) {
                    $history = new OrderHistory();
                    $history->id_order = $idOrder;
                    $history->changeIdOrderState((int) Configuration::get('PS_OS_REFUND'), $order);
                    $history->addWithemail();
                }
            }

            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
        }

        if (Tools::isSubmit('submitPaymeModule')) {
            $output .= $this->postProcess();
        }

        // Admin CSS — inject via link tag to ensure it loads
        $cssUrl = $this->getPathUri() . 'views/css/payme-admin.css?v=' . self::MODULE_VERSION;
        $this->context->controller->addCSS($cssUrl);

        // Also inject inline as fallback (addCSS may not work after header render)
        $output .= '<link rel="stylesheet" href="' . htmlspecialchars($cssUrl) . '">';
        // Build modern header
        $env = $this->getEnvironment();
        $badgeClass = $env === 'production' ? 'payme-admin-header__badge--production' : 'payme-admin-header__badge--sandbox';
        $badgeText = $env === 'production' ? 'PRODUCCIÓN' : 'SANDBOX';

        $logoUrl = $this->getPathUri() . 'views/img/payme-logo.png';
        $logoExists = file_exists(_PS_MODULE_DIR_ . $this->name . '/views/img/payme-logo.png');

        $header = '<div class="payme-admin-wrap">';
        $header .= '<div class="payme-admin-header">';
        $header .= '<div class="payme-admin-header__logo">';
        if ($logoExists) {
            $header .= '<img src="' . $logoUrl . '" alt="Payme">';
        } else {
            $header .= '💳';
        }
        $header .= '</div>';
        $header .= '<div class="payme-admin-header__info">';
        $header .= '<h2>Payme Gateway</h2>';
        $header .= '<p>Acepta pagos con tarjeta, Yape, QR, transferencias bancarias y más métodos de pago.</p>';
        $header .= '</div>';
        $header .= '<span class="payme-admin-header__badge ' . $badgeClass . '">' . $badgeText . '</span>';
        $header .= '</div>';

        // Status card
        $clientId = Configuration::get('PAYME_CLIENT_ID');
        $clientSecret = Configuration::get('PAYME_CLIENT_SECRET');
        $merchantCode = Configuration::get('PAYME_MERCHANT_CODE');

        $header .= '<div class="payme-status-card">';
        $header .= '<h3>Estado de la Configuración</h3>';
        $header .= '<ul>';
        $header .= '<li><span class="' . (!empty($clientId) ? 'ok' : 'fail') . '">' . (!empty($clientId) ? '✓' : '✗') . '</span> Client ID</li>';
        $header .= '<li><span class="' . (!empty($clientSecret) ? 'ok' : 'fail') . '">' . (!empty($clientSecret) ? '✓' : '✗') . '</span> Client Secret</li>';
        $header .= '<li><span class="' . (!empty($merchantCode) ? 'ok' : 'fail') . '">' . (!empty($merchantCode) ? '✓' : '✗') . '</span> Merchant Code</li>';
        $header .= '<li><span class="' . ($this->active ? 'ok' : 'fail') . '">' . ($this->active ? '✓' : '✗') . '</span> Módulo Activo</li>';
        $header .= '</ul>';
        $header .= '</div>';

        $output = $header . $output . $this->renderForm();
        $output .= '</div>'; // close .payme-admin-wrap

        return $output;
    }
}
