# Pay-me PrestaShop Plugin

Plugin oficial de Pay-me (Alignet) para integrar pagos en PrestaShop de forma rapida, segura y con una experiencia de checkout flexible.

## Descarga

Descarga la ultima version del plugin desde GitHub Releases:

<https://github.com/alignet-docs/alignet-payme-prestashop/releases/latest>

Si deseas ver todas las versiones publicadas:

<https://github.com/alignet-docs/alignet-payme-prestashop/releases>

Para instalar el plugin en PrestaShop, descarga el archivo `.zip` adjunto en cada release.

Importante: no utilices `Code > Download ZIP` si ya existe un `.zip` oficial publicado en `Releases`.

## Que soluciones brinda

Este plugin te ayuda a:

- Integrar Pay-me en PrestaShop sin desarrollo personalizado.
- Aceptar multiples metodos de pago desde una sola pasarela.
- Ofrecer pagos con tarjeta, Yape, QR, transferencia bancaria, Cuotealo BCP y PagoEfectivo.
- Mostrar los metodos de pago en modo embebido o en popup.
- Elegir si los metodos se presentan juntos en una sola pasarela o por separado.
- Confirmar pagos asincronos mediante notificaciones S2S (server-to-server).
- Gestionar extornos completos desde la administracion de pedidos.
- Consultar transacciones y logs tecnicos del modulo.
- Operar en ambientes `sandbox` y `produccion`.

## Requisitos

- PrestaShop `1.7.0.0` o superior
- PrestaShop probado hasta `8.x`
- PHP compatible con tu version de PrestaShop
- Extensiones PHP activas: `cURL`, `OpenSSL` y `JSON`
- Sitio con `HTTPS`
- Credenciales activas de Pay-me: `client_id`, `client_secret` y `merchant_code`

## Metodos de pago soportados

- Tarjeta de credito y debito
- Yape
- Codigo QR
- Transferencia bancaria
- Cuotealo BCP
- PagoEfectivo

## Instalacion rapida

1. Descarga el archivo `.zip` desde la seccion **Releases**.
2. Ingresa a tu panel de PrestaShop.
3. Ve a `Modulos > Module Manager > Subir un modulo`.
4. Selecciona el archivo `.zip` descargado.
5. Haz clic en `Instalar`.
6. Activa el plugin si PrestaShop no lo activa automaticamente.

Importante:

- El nombre tecnico del modulo es `payme`.
- La carpeta final instalada en PrestaShop debe quedar como `/modules/payme`.

## Configuracion

1. Ve a `Modulos > Module Manager`.
2. Busca y selecciona `Payme Gateway`.
3. Habilita el modulo.
4. Elige el ambiente de trabajo: `sandbox` para pruebas o `production` para ventas reales.
5. Ingresa tus credenciales: `client_id`, `client_secret` y `merchant_code`.
6. Configura el pais y la moneda.
7. Selecciona los metodos de pago que deseas mostrar.
8. Define el modo de visualizacion: embebido en el checkout o popup en la misma pagina.
9. Define el tipo de visualizacion: junto, con una sola pasarela Pay-me, o separado, con un contenedor por metodo.
10. Copia la `URL S2S` generada por el modulo y compartela con Pay-me si tu flujo requiere confirmacion asincrona.
11. Guarda los cambios.

## URLs importantes

El modulo genera automaticamente estas URLs:

- `Redirect URL`
- `URL S2S (Notificacion Server-to-Server)`

La `Redirect URL` se usa para el retorno del checkout.

La `URL S2S` debe configurarse en Pay-me para notificaciones asincronas, especialmente en metodos como:

- `QR`
- `PagoEfectivo`
- `Transferencia bancaria`

## Notas importantes

- En produccion se recomienda usar `HTTPS` y un certificado SSL valido.
- El estado final de algunos pagos puede confirmarse de manera asincrona via S2S, especialmente en QR, PagoEfectivo o transferencia bancaria.
- El modo debug debe utilizarse solo durante pruebas o troubleshooting.
- El plugin crea tablas propias para transacciones, contadores y logs usando el prefijo configurado en PrestaShop.
- Para actualizar el plugin, descarga una nueva version desde `Releases` e instalala sobre la version existente.
- Si publicas este codigo en otro repositorio, la carpeta del modulo instalada debe seguir llamandose `payme`.

## Soporte

Si necesitas ayuda o deseas reportar un problema, utiliza el repositorio de GitHub:

- Repositorio: <https://github.com/alignet-docs/alignet-payme-prestashop>
- Releases: <https://github.com/alignet-docs/alignet-payme-prestashop/releases>
- Issues: <https://github.com/alignet-docs/alignet-payme-prestashop/issues>

Al reportar un incidente, incluye de ser posible:

- version del plugin
- version de PrestaShop
- version de PHP
- ambiente usado (`sandbox` o `produccion`)
- logs o capturas del error

Importante: nunca compartas publicamente tu `client_secret`.

## Licencia

Este plugin se distribuye bajo licencia `AFL-3.0`.
