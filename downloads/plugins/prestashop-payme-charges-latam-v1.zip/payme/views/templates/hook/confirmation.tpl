{**
 * Payme - Payment Return Confirmation Template
 *}

<div class="payme-payment-confirmation">
    {if isset($is_error) && $is_error}
        {* Error already shown by the banner — no duplicate needed *}
    {else}
        <div class="payme-confirmation-details">
            <p>{l s='Tu pago ha sido procesado correctamente.' mod='payme'}</p>
            <ul>
                <li><strong>{l s='Referencia del pedido:' mod='payme'}</strong> {$order_reference|escape:'html':'UTF-8'}</li>
                <li><strong>{l s='Total:' mod='payme'}</strong> {$order_total}</li>
                <li><strong>{l s='Estado:' mod='payme'}</strong> {$status_name|escape:'html':'UTF-8'}</li>
            </ul>
        </div>
    {/if}
</div>
