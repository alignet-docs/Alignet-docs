{**
 * Payme - Enhanced Order Confirmation Banner
 * Supports confirmed (green), pending (orange), and error (red) states
 *}

{if isset($payme_is_error) && $payme_is_error}
<style>
    /* Hide PrestaShop default confirmation header when payment failed */
    #order-confirmation .card-title,
    .order-confirmation .card-title,
    #order-confirmation .h1.card-title,
    .order-confirmation h3.h1,
    .order-confirmation > .card > .card-body > h3,
    .order-confirmation > .card > .card-body > p:first-of-type,
    #content-hook_payment_return .card-title,
    .page-order-confirmation .card-body > h3.h1,
    .page-order-confirmation .card-body > p:first-of-type {
        display: none !important;
    }
</style>
<div class="payme-success-banner payme-error-banner" style="background:linear-gradient(135deg,#fef2f2 0%,#fee2e2 100%);border:2px solid #ef4444;border-radius:10px;padding:24px;text-align:center;margin-bottom:20px;">
    <div class="payme-success-banner__icon" style="font-size:48px;color:#ef4444;margin-bottom:8px;">✕</div>
    <h2 class="payme-success-banner__title" style="color:#991b1b;font-size:22px;margin:0 0 8px;">{l s='Pago Denegado' mod='payme'}</h2>
    <p class="payme-success-banner__subtitle" style="color:#b91c1c;font-size:14px;margin:0;">{l s='Tu pago no pudo ser procesado. La transacción fue rechazada.' mod='payme'}</p>
</div>
{elseif isset($payme_is_pending) && $payme_is_pending}
<div class="payme-success-banner payme-pending-banner">
    <div class="payme-success-banner__icon">⏳</div>
    <h2 class="payme-success-banner__title">{l s='Pedido Pendiente de Pago' mod='payme'}</h2>
    <p class="payme-success-banner__subtitle">{l s='Tu pedido ha sido registrado. Completa el pago para confirmarlo.' mod='payme'}</p>
</div>
{else}
<div class="payme-success-banner">
    <div class="payme-success-banner__icon">✓</div>
    <h2 class="payme-success-banner__title">{l s='¡Pedido Confirmado!' mod='payme'}</h2>
    <p class="payme-success-banner__subtitle">{l s='Tu pago ha sido procesado exitosamente' mod='payme'}</p>
</div>
{/if}
