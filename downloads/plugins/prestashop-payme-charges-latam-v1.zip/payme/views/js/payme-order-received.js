/**
 * Payme Order Confirmation Page - Enhanced UX for PrestaShop
 */
(function() {
    'use strict';

    function init() {
        // Detect order confirmation page
        var isConfirmation = document.querySelector('.order-confirmation')
            || document.querySelector('#order-confirmation')
            || window.location.href.indexOf('order-confirmation') !== -1;

        if (!isConfirmation) return;

        enhanceConfirmationPage();
    }

    function enhanceConfirmationPage() {
        // Hide default "Your order is confirmed" heading if our banner is present
        var banner = document.querySelector('.payme-success-banner');
        var status = (typeof payme_order !== 'undefined' && payme_order.status) ? payme_order.status : '';

        if (banner) {
            // Error state: swap banner to error style
            if (status === 'error' && !banner.classList.contains('payme-error-banner')) {
                banner.classList.add('payme-error-banner');
                banner.style.background = 'linear-gradient(135deg,#fef2f2 0%,#fee2e2 100%)';
                banner.style.borderColor = '#ef4444';
                var icon = banner.querySelector('.payme-success-banner__icon');
                var title = banner.querySelector('.payme-success-banner__title');
                var subtitle = banner.querySelector('.payme-success-banner__subtitle');
                if (icon) { icon.textContent = '✕'; icon.style.color = '#ef4444'; }
                if (title) { title.textContent = 'Pago Denegado'; title.style.color = '#991b1b'; }
                if (subtitle) { subtitle.textContent = 'Tu pago no pudo ser procesado. La transacción fue rechazada.'; subtitle.style.color = '#b91c1c'; }
            }

            // Pending state: swap banner to pending style
            if (status === 'pending' && !banner.classList.contains('payme-pending-banner')) {
                banner.classList.add('payme-pending-banner');
                var icon = banner.querySelector('.payme-success-banner__icon');
                var title = banner.querySelector('.payme-success-banner__title');
                var subtitle = banner.querySelector('.payme-success-banner__subtitle');
                if (icon) icon.textContent = '⏳';
                if (title) title.textContent = 'Pedido Pendiente de Pago';
                if (subtitle) subtitle.textContent = 'Tu pedido ha sido registrado. Completa el pago para confirmarlo.';
            }

            // Hide PrestaShop's default "SU PEDIDO ESTÁ CONFIRMADO" heading
            var allHeadings = document.querySelectorAll('h3, h2, .card-title, .h1');
            for (var i = 0; i < allHeadings.length; i++) {
                var text = allHeadings[i].textContent.trim().toLowerCase();
                if (text.indexOf('order is confirmed') !== -1 || text.indexOf('pedido está confirmado') !== -1 || text.indexOf('su pedido') !== -1) {
                    if (status === 'error') {
                        allHeadings[i].innerHTML = '❌ Pago Denegado';
                        allHeadings[i].style.color = '#991b1b';
                    } else {
                        allHeadings[i].style.display = 'none';
                    }
                }
            }

            // Also hide the default subtitle "Se ha enviado un email..."
            if (status === 'error') {
                var allParagraphs = document.querySelectorAll('.card-body > p, .order-confirmation p');
                for (var k = 0; k < allParagraphs.length; k++) {
                    var stxt = allParagraphs[k].textContent.trim().toLowerCase();
                    if (stxt.indexOf('email') !== -1 || stxt.indexOf('correo') !== -1) {
                        allParagraphs[k].style.display = 'none';
                    }
                }
            }
        }

        // Enhance order details table
        var tables = document.querySelectorAll('.order-confirmation-table, table.table');
        for (var j = 0; j < tables.length; j++) {
            tables[j].classList.add('payme-order-table');
        }

        // Add back to shop button if not present
        addBackToShopButton();
    }

    function addBackToShopButton() {
        if (document.querySelector('.payme-back-to-shop')) return;

        var container = document.querySelector('.order-confirmation')
            || document.querySelector('#order-confirmation')
            || document.querySelector('#content');

        if (!container) return;

        var shopUrl = (typeof prestashop !== 'undefined' && prestashop.urls && prestashop.urls.pages)
            ? prestashop.urls.pages.index
            : '/';

        var btn = document.createElement('div');
        btn.className = 'payme-back-to-shop';
        btn.innerHTML = '<a href="' + shopUrl + '" class="payme-btn-shop">← Volver a la tienda</a>';
        container.appendChild(btn);
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
