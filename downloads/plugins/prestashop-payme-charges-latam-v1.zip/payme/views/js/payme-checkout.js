/**
 * Payme Checkout JS for PrestaShop
 * Handles Flex SDK integration with accordion layout (like WooCommerce)
 */
(function() {
    'use strict';

    if (typeof payme_config === 'undefined') {
        return;
    }

    var payme = {
        paymentForm: null,
        selectedMethod: null,
        currentContainer: null,
        loadedMethods: {},

        init: function() {
            this.bindAccordion();
            this.bindJuntoMode();
            this.hideConfirmButton();
            this.stylePaymeOption();
        },

        /**
         * Style the Payme payment option card
         */
        stylePaymeOption: function() {
            var self = this;
            var check = function() {
                var allOptions = document.querySelectorAll('.payment-option');
                for (var i = 0; i < allOptions.length; i++) {
                    var opt = allOptions[i];
                    var hasAccordion = opt.querySelector('.payme-accordion');
                    var hasPaymeContainer = opt.querySelector('.payme-checkout-container');
                    var img = opt.querySelector('img');
                    var isPayme = hasAccordion || hasPaymeContainer
                        || (img && img.src && img.src.indexOf('payme') !== -1);

                    if (isPayme && !opt.classList.contains('payme-payment-option')) {
                        opt.classList.add('payme-payment-option');
                        var label = opt.querySelector('label');
                        if (label) label.classList.add('payme-payment-label');
                    }
                }
            };
            check();
            // Re-check when DOM changes
            var obs = new MutationObserver(check);
            obs.observe(document.body, { childList: true, subtree: true });
        },

        /**
         * Bind accordion radio buttons for separado mode
         */
        bindAccordion: function() {
            var self = this;

            document.addEventListener('change', function(e) {
                if (!e.target.classList.contains('payme-accordion__radio')) return;

                var method = e.target.value;
                var item = e.target.closest('.payme-accordion__item');
                var accordion = e.target.closest('.payme-accordion');
                if (!accordion || !item) return;

                // Close all
                var items = accordion.querySelectorAll('.payme-accordion__item');
                for (var i = 0; i < items.length; i++) {
                    items[i].classList.remove('active');
                    items[i].querySelector('.payme-accordion__body').style.display = 'none';
                }

                // Open selected
                item.classList.add('active');
                item.querySelector('.payme-accordion__body').style.display = 'block';

                self.selectedMethod = method;

                // Load Flex if not already loaded, or retry if previous attempt failed
                var flexContainer = item.querySelector('.payme-embedded-form');
                var hasError = flexContainer && flexContainer.querySelector('.payme-error');
                if (flexContainer && (!self.loadedMethods[method] || hasError)) {
                    self.loadedMethods[method] = true;
                    self.currentContainer = flexContainer;
                    self.getPaymentData(flexContainer, method);
                }
            });

            // Also watch for PrestaShop revealing the additional-information section
            var observer = new MutationObserver(function() {
                var accordion = document.querySelector('.payme-accordion');
                if (accordion && accordion.offsetParent !== null && !accordion.dataset.bound) {
                    accordion.dataset.bound = 'true';
                }
            });
            observer.observe(document.body, { childList: true, subtree: true, attributes: true });
        },

        /**
         * Handle "junto" mode — single Flex container
         */
        bindJuntoMode: function() {
            var self = this;

            // Junto + Modal: bind the "Pagar" button
            if (payme_config.display_mode === 'popup') {
                document.addEventListener('click', function(e) {
                    if (e.target && e.target.id === 'payme-popup-pay-btn') {
                        e.preventDefault();
                        var container = document.getElementById('payme-flex-container');
                        if (container && !container.dataset.loading) {
                            container.dataset.loading = 'true';
                            self.currentContainer = container;
                            self.getPaymentData(container, null);
                        }
                    }
                });
                return; // Don't auto-initialize for popup mode
            }

            // Junto + Embedded: auto-initialize when container becomes visible
            var observer = new MutationObserver(function() {
                var container = document.getElementById('payme-flex-container');
                if (container && container.offsetParent !== null && !container.dataset.initialized) {
                    container.dataset.initialized = 'true';
                    self.currentContainer = container;
                    self.getPaymentData(container, null);
                }
            });
            observer.observe(document.body, { childList: true, subtree: true, attributes: true });

            // Initial check
            setTimeout(function() {
                var container = document.getElementById('payme-flex-container');
                if (container && container.offsetParent !== null && !container.dataset.initialized) {
                    container.dataset.initialized = 'true';
                    self.currentContainer = container;
                    self.getPaymentData(container, null);
                }
            }, 800);
        },

        /**
         * Request payment data from server (nonce + payload)
         * Retries once on failure (handles API cold start / transient errors)
         */
        getPaymentData: function(container, method, retryCount) {
            var self = this;
            retryCount = retryCount || 0;
            var maxRetries = 2;

            // Build URL with action as query param (more reliable in PrestaShop)
            var url = payme_config.ajax_url;
            url += (url.indexOf('?') === -1 ? '?' : '&') + 'ajax=1&action=get_payment_data';
            if (method) {
                url += '&selected_method=' + encodeURIComponent(method);
            }

            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);

            xhr.onload = function() {
                if (xhr.status === 200) {
                    try {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            self.loadPaymeFlex(container, response);
                        } else {
                            console.warn('Payme AJAX error:', response.error, '(attempt ' + (retryCount + 1) + ')');
                            if (retryCount < maxRetries) {
                                setTimeout(function() {
                                    self.getPaymentData(container, method, retryCount + 1);
                                }, 1000 + (retryCount * 1000));
                            } else {
                                self.showError(container, response.error || payme_config.messages.error);
                            }
                        }
                    } catch (e) {
                        console.warn('Payme AJAX parse error:', xhr.responseText.substring(0, 200), '(attempt ' + (retryCount + 1) + ')');
                        if (retryCount < maxRetries) {
                            setTimeout(function() {
                                self.getPaymentData(container, method, retryCount + 1);
                            }, 1000 + (retryCount * 1000));
                        } else {
                            self.showError(container, payme_config.messages.error);
                        }
                    }
                } else {
                    console.warn('Payme AJAX HTTP ' + xhr.status, xhr.responseText.substring(0, 200), '(attempt ' + (retryCount + 1) + ')');
                    if (retryCount < maxRetries) {
                        setTimeout(function() {
                            self.getPaymentData(container, method, retryCount + 1);
                        }, 1000 + (retryCount * 1000));
                    } else {
                        self.showError(container, payme_config.messages.error);
                    }
                }
            };
            xhr.onerror = function() {
                if (retryCount < maxRetries) {
                    setTimeout(function() {
                        self.getPaymentData(container, method, retryCount + 1);
                    }, 1000 + (retryCount * 1000));
                } else {
                    self.showError(container, payme_config.messages.error);
                }
            };
            xhr.send();
        },

        /**
         * Initialize Flex SDK in the container
         */
        loadPaymeFlex: function(container, paymentData) {
            var self = this;
            container.innerHTML = '';
            container.classList.add('loading');
            container.classList.remove('payme-loading');

            if (payme_config.display_mode === 'popup') {
                this.popupPaymentData = paymentData;
                container.classList.remove('loading');
                // Reset loading flag for junto+popup button
                delete container.dataset.loading;
                this.openPaymentPopup();
                return;
            }

            // Wait for Flex SDK to be available (may still be loading from CDN)
            if (typeof FlexPaymentForms === 'undefined') {
                self._flexWaitCount = (self._flexWaitCount || 0) + 1;
                if (self._flexWaitCount <= 20) { // max ~10 seconds
                    setTimeout(function() {
                        self.loadPaymeFlex(container, paymentData);
                    }, 500);
                    return;
                }
                container.classList.remove('loading');
                this.showError(container, payme_config.messages.error);
                return;
            }
            self._flexWaitCount = 0;

            var flexForm = document.createElement('div');
            flexForm.id = 'payme-flex-form-' + (this.selectedMethod || 'main');
            flexForm.className = 'payme-flex-form';
            container.appendChild(flexForm);

            try {
                var flexSettings = { show_close_button: false };
                if (payme_config.hide_animation === 'yes') {
                    flexSettings.display_result_screen = false;
                }

                var paymentForm = new FlexPaymentForms({
                    nonce: paymentData.nonce,
                    payload: paymentData.payload,
                    settings: flexSettings,
                    display_settings: paymentData.display_settings
                });

                paymentForm.init(
                    flexForm,
                    this.responseCallback.bind(this),
                    this.trackingCallback.bind(this),
                    this.onErrorCallback.bind(this)
                );

                this.paymentForm = paymentForm;

                setTimeout(function() {
                    container.classList.remove('loading');
                    container.classList.add('visible');
                    self.hideOperationNumber(container);
                    setTimeout(function() { self.hideOperationNumber(container); }, 1500);
                    self.observeOperationNumber(container);
                }, 500);
            } catch (error) {
                console.warn('Payme Flex init error:', error);
                container.classList.remove('loading');
                // Auto-retry with fresh nonce
                self._initRetryCount = (self._initRetryCount || 0) + 1;
                if (self._initRetryCount <= 3) {
                    var method = self.selectedMethod;
                    if (method) self.loadedMethods[method] = false;
                    setTimeout(function() {
                        self.getPaymentData(container, method);
                    }, 2000 * self._initRetryCount);
                } else {
                    self._initRetryCount = 0;
                    this.showError(container, payme_config.messages.error);
                }
            }
        },

        /**
         * Handle payment response from Flex
         */
        responseCallback: function(response) {
            // The Flex SDK only calls the success callback when payment is approved.
            // We trust the SDK and send the result to the server for order creation.

            // Terminate Flex SDK
            try {
                if (this.paymentForm && this.paymentForm.terminate) {
                    this.paymentForm.terminate();
                }
            } catch (e) {
                console.warn('Payme terminate:', e);
            }

            // Show processing overlay immediately
            this.showProcessingOverlay();

            var params = 'payment_result=' + encodeURIComponent(JSON.stringify(response));
            var xhr = new XMLHttpRequest();
            xhr.open('POST', payme_config.validation_url, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                try {
                    var data = JSON.parse(xhr.responseText);
                    if (data.redirect) {
                        window.location.replace(data.redirect);
                    } else if (data.success && data.redirect) {
                        window.location.replace(data.redirect);
                    } else {
                        payme.removeProcessingOverlay();
                        window.location.replace(payme_config.checkout_url || window.location.href);
                    }
                } catch (e) {
                    payme.removeProcessingOverlay();
                    window.location.replace(payme_config.checkout_url || window.location.href);
                }
            };
            xhr.onerror = function() {
                payme.removeProcessingOverlay();
                window.location.replace(payme_config.checkout_url || window.location.href);
            };
            xhr.send(params);
        },

        responseCodes: {
            '00': 'Pago Exitoso',
            '01': 'Denegado por el emisor',
            '03': 'Datos de comercio Inválidos',
            '04': 'Denegado por el emisor',
            '05': 'Denegado por el emisor',
            '08': 'Denegado por el emisor',
            '10': 'Aprobación Parcial Denegada',
            '12': 'Transacción no válida',
            '13': 'Monto invalido',
            '14': 'Número de cuenta no válido',
            '15': 'Emisor no disponible',
            '30': 'Error durante el proceso emisor',
            '41': 'Denegado por el emisor',
            '43': 'Denegado por el emisor',
            '51': 'Fondos insuficientes',
            '54': 'Tarjeta expirada',
            '55': 'PIN incorrecto',
            '57': 'La transacción no es permitida',
            '58': 'La transacción no es permitida',
            '61': 'Excede el límite del monto',
            '62': 'Denegado por el emisor',
            '63': 'Violación de seguridad',
            '65': 'Error durante el proceso emisor',
            '70': 'Denegado por el emisor',
            '71': 'Error de clave PIN',
            '75': 'Excedió el numero de intentos',
            '76': 'Error durante el proceso emisor',
            '77': 'Error durante el proceso emisor',
            '78': 'Error durante el proceso emisor',
            '79': 'Denegado por la marca',
            '81': 'Denegado por el emisor',
            '82': 'Denegado por la marca',
            '83': 'Denegado por el emisor',
            '84': 'Denegado por el emisor',
            '85': 'Denegado por el emisor',
            '86': 'Error durante el proceso emisor',
            '87': 'Denegado por el emisor',
            '88': 'Error de ingreso de datos',
            '89': 'Denegado por el emisor',
            '91': 'Error durante el proceso emisor',
            '92': 'Error durante el proceso emisor',
            '94': 'Numero pedido duplicado',
            '96': 'Error durante el proceso emisor'
        },

        getResponseCodeMessage: function(code) {
            if (!code && code !== 0) return 'El pago no pudo ser procesado. Inténtalo nuevamente.';
            var strCode = String(code).padStart(2, '0');
            var msg = this.responseCodes[strCode];
            if (msg) return msg + ' (Código: ' + strCode + ')';
            return 'El pago no pudo ser procesado. Código: ' + strCode;
        },

        trackingCallback: function() {},
        onErrorCallback: function(err) {
            console.warn('Payme Flex SDK error:', err);
            var container = this.currentContainer;
            if (!container) return;

            // Auto-retry: request fresh nonce + operation number and re-init SDK
            this._sdkRetryCount = (this._sdkRetryCount || 0) + 1;
            if (this._sdkRetryCount <= 3) {
                var self = this;
                var method = this.selectedMethod;
                console.warn('Payme: SDK session failed, retrying with fresh nonce (attempt ' + this._sdkRetryCount + ')...');

                // Reset loaded state so getPaymentData runs again
                if (method) {
                    this.loadedMethods[method] = false;
                }

                // Wait before retry (increasing delay)
                setTimeout(function() {
                    self.getPaymentData(container, method);
                }, 2000 * self._sdkRetryCount);
            } else {
                this._sdkRetryCount = 0;
                this.showError(container, payme_config.messages.error);
            }
        },

        hideConfirmButton: function() {
            var style = document.createElement('style');
            style.id = 'payme-hide-confirm';
            style.textContent =
                /* Hide "Place order" button and terms checkbox when Payme is selected */
                '#payment-confirmation { display: none !important; }' +
                '#conditions-to-approve { display: none !important; }';
            document.head.appendChild(style);

            // Show/hide based on which payment option is selected
            var self = this;
            document.addEventListener('change', function(e) {
                if (e.target.name === 'payment-option') {
                    self.toggleConfirmVisibility();
                }
            });

            // Also observe for PrestaShop re-rendering
            var obs = new MutationObserver(function() { self.toggleConfirmVisibility(); });
            obs.observe(document.body, { childList: true, subtree: true });
        },

        toggleConfirmVisibility: function() {
            var styleEl = document.getElementById('payme-hide-confirm');
            if (!styleEl) return;

            // Check if Payme payment option is currently selected
            var selectedOption = document.querySelector('input[name="payment-option"]:checked');
            if (!selectedOption) { styleEl.disabled = true; return; }

            var parentOption = selectedOption.closest('.payment-option');
            var isPayme = false;
            if (parentOption) {
                isPayme = parentOption.querySelector('.payme-accordion') !== null
                    || parentOption.querySelector('.payme-checkout-container') !== null
                    || parentOption.classList.contains('payme-payment-option');
            }

            styleEl.disabled = !isPayme;
        },

        showError: function(container, message) {
            container.innerHTML = '<div class="payme-error">⚠️ ' + message + '</div>';
        },

        showProcessingOverlay: function() {
            if (document.getElementById('payme-processing-overlay')) return;
            var overlay = document.createElement('div');
            overlay.id = 'payme-processing-overlay';
            overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(255,255,255,0.92);z-index:999999;display:flex;align-items:center;justify-content:center;flex-direction:column;';
            overlay.innerHTML = '<div style="width:40px;height:40px;border:3px solid #e5e7eb;border-top:3px solid #3b82f6;border-radius:50%;animation:payme-spin 0.8s linear infinite;margin-bottom:16px;"></div>'
                + '<p style="font-size:16px;color:#1e293b;font-weight:600;margin:0;">Procesando tu pago...</p>'
                + '<p style="font-size:13px;color:#64748b;margin:6px 0 0;">Serás redirigido en un momento</p>';
            document.body.appendChild(overlay);
        },

        removeProcessingOverlay: function() {
            var overlay = document.getElementById('payme-processing-overlay');
            if (overlay) overlay.remove();
        },

        openPaymentPopup: function() {
            if (!this.popupPaymentData) {
                window.location.replace(payme_config.checkout_url || window.location.href);
                return;
            }

            // Wait for Flex SDK to be available
            var self = this;
            if (typeof FlexPaymentForms === 'undefined') {
                self._popupFlexWaitCount = (self._popupFlexWaitCount || 0) + 1;
                if (self._popupFlexWaitCount <= 20) {
                    setTimeout(function() { self.openPaymentPopup(); }, 500);
                    return;
                }
                window.location.replace(payme_config.checkout_url || window.location.href);
                return;
            }
            self._popupFlexWaitCount = 0;

            var self = this;
            var data = this.popupPaymentData;
            var hideAnim = payme_config.hide_animation === 'yes';

            var flexSettings = { show_close_button: false };
            if (hideAnim) flexSettings.display_result_screen = false;

            // Hide accordion expanded content while modal is open
            document.querySelectorAll('.payme-embedded-form').forEach(function(el) {
                el.style.display = 'none';
            });
            // Also hide any loading spinners in the accordion
            document.querySelectorAll('.payme-accordion-body .payme-loading, .payme-method-item .payme-loading').forEach(function(el) {
                el.style.display = 'none';
            });

            // Remove any existing modal
            var existing = document.getElementById('payme-modal-overlay');
            if (existing) existing.remove();

            // Create fullscreen modal overlay
            var overlay = document.createElement('div');
            overlay.id = 'payme-modal-overlay';
            overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:999999;display:flex;align-items:center;justify-content:center;animation:payme-fade-in 0.2s ease;';

            var modal = document.createElement('div');
            modal.style.cssText = 'background:#fff;border-radius:12px;width:95%;max-width:560px;max-height:90vh;overflow-y:auto;position:relative;box-shadow:0 20px 60px rgba(0,0,0,0.3);animation:payme-slide-up 0.25s ease;';

            var header = document.createElement('div');
            header.style.cssText = 'display:flex;align-items:center;justify-content:flex-end;padding:8px 12px;';

            var closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.style.cssText = 'background:none;border:none;cursor:pointer;padding:4px;color:#94a3b8;font-size:20px;line-height:1;';
            closeBtn.innerHTML = '✕';
            closeBtn.addEventListener('click', function() { self.closePaymentModal(); });
            header.appendChild(closeBtn);

            var body = document.createElement('div');
            body.style.cssText = 'padding:16px 20px 20px;';

            var flexTarget = document.createElement('div');
            flexTarget.id = 'payme-modal-flex-form';
            flexTarget.className = 'payme-loading';
            flexTarget.style.cssText = 'min-height:300px;';
            body.appendChild(flexTarget);

            modal.appendChild(header);
            modal.appendChild(body);
            overlay.appendChild(modal);

            var style = document.createElement('style');
            style.textContent = '@keyframes payme-fade-in{from{opacity:0}to{opacity:1}}@keyframes payme-slide-up{from{transform:translateY(30px);opacity:0}to{transform:translateY(0);opacity:1}}';
            overlay.appendChild(style);

            document.body.appendChild(overlay);
            document.body.style.overflow = 'hidden';

            try {
                var pf = new FlexPaymentForms({
                    nonce: data.nonce,
                    payload: data.payload,
                    settings: flexSettings,
                    display_settings: data.display_settings
                });

                self._modalFlexInstance = pf;

                pf.init(
                    flexTarget,
                    function(resp) {
                        try { pf.terminate && pf.terminate(); } catch (e) {}
                        self.closePaymentModal();
                        self.responseCallback(resp);
                    },
                    function(trackData) {},
                    function(err) {
                        console.warn('Payme modal SDK error:', err);
                        self.closePaymentModal();
                        // Auto-retry with fresh nonce
                        self._modalRetryCount = (self._modalRetryCount || 0) + 1;
                        if (self._modalRetryCount <= 3) {
                            console.warn('Payme: modal SDK failed, retrying (attempt ' + self._modalRetryCount + ')...');
                            setTimeout(function() {
                                self.getPaymentData(self.currentContainer, self.selectedMethod);
                            }, 2000 * self._modalRetryCount);
                        } else {
                            self._modalRetryCount = 0;
                            self.onErrorCallback(err);
                        }
                    }
                );

                setTimeout(function() {
                    flexTarget.classList.remove('payme-loading');
                    self.hideOperationNumber(flexTarget);
                    setTimeout(function() { self.hideOperationNumber(flexTarget); }, 1500);
                    self.observeOperationNumber(flexTarget);
                }, 500);

            } catch (err) {
                self.closePaymentModal();
                window.location.replace(payme_config.checkout_url || window.location.href);
            }
        },

        closePaymentModal: function() {
            var overlay = document.getElementById('payme-modal-overlay');
            if (overlay) overlay.remove();
            document.body.style.overflow = '';
            if (this._modalFlexInstance) {
                try { this._modalFlexInstance.terminate && this._modalFlexInstance.terminate(); } catch (e) {}
                this._modalFlexInstance = null;
            }
        },

        hideOperationNumber: function(container) {
            var nodes = container.querySelectorAll('*');
            for (var i = 0; i < nodes.length; i++) {
                var text = nodes[i].textContent || '';
                if (/Operacion\s+Nro/i.test(text) && nodes[i].children.length === 0) {
                    nodes[i].style.display = 'none';
                }
            }
        },

        observeOperationNumber: function(container) {
            if (this._opObs) this._opObs.disconnect();
            var self = this;
            this._opObs = new MutationObserver(function() { self.hideOperationNumber(container); });
            this._opObs.observe(container, { childList: true, subtree: true, characterData: true });
            setTimeout(function() { if (self._opObs) { self._opObs.disconnect(); self._opObs = null; } }, 10000);
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() { payme.init(); });
    } else {
        payme.init();
    }

    window.paymeCheckout = payme;
})();
